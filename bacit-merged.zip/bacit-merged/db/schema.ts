import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core'

/** Whole learner state (see `ProgressState` in src/lib/progress.ts), one row per account. */
export const studentProgress = pgTable('student_progress', {
  userId: text('user_id').primaryKey(),
  data: jsonb('data').notNull(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
})

/** One finished exam simulation. */
export const examAttempts = pgTable(
  'exam_attempts',
  {
    id: serial('id').primaryKey(),
    userId: text('user_id').notNull(),
    courseId: text('course_id').notNull(),
    variant: text('variant').notNull(),
    score: integer('score').notNull(),
    correct: integer('correct').notNull(),
    total: integer('total').notNull(),
    passed: boolean('passed').notNull(),
    durationSeconds: integer('duration_seconds').notNull(),
    domains: jsonb('domains').notNull(),
    createdAt: timestamp('created_at').notNull().defaultNow(),
  },
  (t) => [index('exam_attempts_user_idx').on(t.userId, t.createdAt)],
)
