import { getUser } from '@netlify/identity'
import { and, desc, eq } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import { examAttempts, studentProgress } from '../../db/schema.js'
import { getCourse } from '../../src/data/courses.js'

const json = (value: unknown, status = 200) =>
  Response.json(value, { status, headers: { 'Cache-Control': 'no-store' } })

const MAX_BODY = 600_000

const answerRecord = z.object({
  correct: z.boolean(),
  attempts: z.number().int().min(0).max(100_000),
  at: z.number(),
})

const examRecord = z.object({
  id: z.string().max(120),
  course: z.string().max(60),
  variant: z.number().int().min(0).max(1000),
  percent: z.number().min(0).max(100),
  correct: z.number().int().min(0).max(1000),
  total: z.number().int().min(1).max(1000),
  at: z.number(),
  seconds: z.number().min(0).max(1_000_000),
  domains: z
    .array(
      z.object({
        module: z.string().max(120),
        correct: z.number().int().min(0).max(1000),
        total: z.number().int().min(0).max(1000),
      }),
    )
    .max(50),
})

const progressSchema = z.object({
  watched: z.record(z.string().max(80), z.literal(true)),
  answers: z.record(z.string().max(80), answerRecord),
  daily: z.record(z.string().max(12), z.record(z.string().max(60), z.number())),
  dailyGoal: z.number().int().min(1).max(500),
  xp: z.number().min(0),
  flagged: z.record(z.string().max(80), z.literal(true)),
  exams: z.array(examRecord).max(500),
  profile: z.object({
    name: z.string().max(120),
    email: z.string().max(200),
    school: z.string().max(200),
    grade: z.string().max(60),
  }),
})

export default async (req: Request) => {
  try {
    const user = await getUser()
    if (!user) return json({ error: 'Autentifică-te pentru a salva progresul.' }, 401)

    if (req.method === 'GET') {
      const [row] = await db
        .select()
        .from(studentProgress)
        .where(eq(studentProgress.userId, user.id))
        .limit(1)
      const attempts = await db
        .select({ createdAt: examAttempts.createdAt })
        .from(examAttempts)
        .where(eq(examAttempts.userId, user.id))
        .orderBy(desc(examAttempts.createdAt))
        .limit(500)
      return json({
        progress: row?.data ?? null,
        examTimes: attempts.map((a) => a.createdAt.getTime()),
      })
    }

    const origin = req.headers.get('origin')
    if (origin && origin !== new URL(req.url).origin) return json({ error: 'Invalid origin' }, 403)

    if (req.method === 'DELETE') {
      await db.delete(studentProgress).where(eq(studentProgress.userId, user.id))
      await db.delete(examAttempts).where(eq(examAttempts.userId, user.id))
      return json({ ok: true })
    }

    if (req.method !== 'PUT' && req.method !== 'POST') {
      return json({ error: 'Method not allowed' }, 405)
    }

    const raw = await req.text()
    if (raw.length > MAX_BODY) return json({ error: 'Payload too large' }, 413)
    const body = JSON.parse(raw) as Record<string, unknown>

    if (req.method === 'PUT') {
      const parsed = progressSchema.safeParse(body.progress)
      if (!parsed.success) return json({ error: 'Invalid progress' }, 400)
      const now = new Date()
      await db
        .insert(studentProgress)
        .values({ userId: user.id, data: parsed.data, updatedAt: now })
        .onConflictDoUpdate({
          target: studentProgress.userId,
          set: { data: parsed.data, updatedAt: now },
        })
      return json({ ok: true })
    }

    if (body.action === 'exam') {
      const parsed = examRecord.safeParse(body.exam)
      if (!parsed.success) return json({ error: 'Invalid exam' }, 400)
      const exam = parsed.data
      const course = getCourse(exam.course)
      if (!course) return json({ error: 'Unknown course' }, 400)
      const createdAt = new Date(exam.at)
      const [existing] = await db
        .select({ id: examAttempts.id })
        .from(examAttempts)
        .where(and(eq(examAttempts.userId, user.id), eq(examAttempts.createdAt, createdAt)))
        .limit(1)
      if (existing) return json({ ok: true, duplicate: true })
      await db.insert(examAttempts).values({
        userId: user.id,
        courseId: course.id,
        variant: String(exam.variant),
        score: Math.round(exam.percent * 10),
        correct: exam.correct,
        total: exam.total,
        passed: exam.percent >= course.exam.passPercent,
        durationSeconds: Math.round(exam.seconds),
        domains: exam.domains,
        createdAt,
      })
      return json({ ok: true })
    }

    return json({ error: 'Unknown action' }, 400)
  } catch {
    return json({ error: 'Serviciul este temporar indisponibil. Încearcă din nou.' }, 503)
  }
}

export const config = { path: '/api/learning' }
