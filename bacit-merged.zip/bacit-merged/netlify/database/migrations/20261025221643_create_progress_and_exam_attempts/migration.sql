CREATE TABLE "exam_attempts" (
	"id" serial PRIMARY KEY,
	"user_id" text NOT NULL,
	"course_id" text NOT NULL,
	"variant" text NOT NULL,
	"score" integer NOT NULL,
	"correct" integer NOT NULL,
	"total" integer NOT NULL,
	"passed" boolean NOT NULL,
	"duration_seconds" integer NOT NULL,
	"domains" jsonb NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "student_progress" (
	"user_id" text PRIMARY KEY,
	"data" jsonb NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "exam_attempts_user_idx" ON "exam_attempts" ("user_id","created_at");