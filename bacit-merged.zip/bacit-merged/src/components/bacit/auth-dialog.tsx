import { useState, type FormEvent } from 'react'
import { login, requestPasswordRecovery, signup, updateUser } from '@netlify/identity'

import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { setAuthUser } from '@/lib/auth'
import { useT } from '@/lib/i18n'

export type AuthMode = 'login' | 'signup' | 'forgot' | 'reset'

export function AuthDialog({
  open,
  onOpenChange,
  mode,
  setMode,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  mode: AuthMode
  setMode: (mode: AuthMode) => void
}) {
  const t = useT()
  const [pending, setPending] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  const title =
    mode === 'login'
      ? t('Bine ai revenit', 'С возвращением')
      : mode === 'signup'
        ? t('Creează-ți contul', 'Создайте аккаунт')
        : mode === 'forgot'
          ? t('Recuperează accesul', 'Восстановление доступа')
          : t('Alege o parolă nouă', 'Задайте новый пароль')

  const description =
    mode === 'login' || mode === 'signup'
      ? t(
          'Cu un cont, progresul tău se salvează și îl regăsești pe orice dispozitiv.',
          'С аккаунтом ваш прогресс сохраняется и доступен на любом устройстве.',
        )
      : mode === 'forgot'
        ? t(
            'Îți trimitem pe e-mail un link pentru resetarea parolei.',
            'Мы отправим на почту ссылку для сброса пароля.',
          )
        : t('Introdu noua parolă pentru contul tău.', 'Введите новый пароль для вашего аккаунта.')

  function change(next: AuthMode) {
    setMode(next)
    setError('')
    setMessage('')
  }

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (pending) return
    const data = new FormData(e.currentTarget)
    const email = String(data.get('email') || '').trim()
    const password = String(data.get('password') || '')
    setPending(true)
    setMessage('')
    setError('')
    try {
      if (mode === 'login') {
        const user = await login(email, password)
        setAuthUser(user)
        onOpenChange(false)
      } else if (mode === 'signup') {
        const user = await signup(email, password, {
          full_name: String(data.get('name') || '').trim(),
        })
        if (user.confirmedAt) {
          setAuthUser(user)
          onOpenChange(false)
        } else {
          setMessage(
            t(
              'Verifică e-mailul și confirmă adresa înainte de a te autentifica.',
              'Откройте письмо и подтвердите адрес, прежде чем войти.',
            ),
          )
        }
      } else if (mode === 'forgot') {
        await requestPasswordRecovery(email)
        setMessage(
          t(
            'Dacă există un cont cu această adresă, linkul de resetare a fost trimis.',
            'Если аккаунт с таким адресом существует, ссылка для сброса отправлена.',
          ),
        )
      } else {
        const user = await updateUser({ password })
        setAuthUser(user)
        onOpenChange(false)
      }
    } catch {
      setError(
        t(
          'Nu am putut finaliza cererea. Verifică datele, confirmă e-mailul sau încearcă din nou.',
          'Не удалось выполнить запрос. Проверьте данные, подтвердите почту или повторите попытку.',
        ),
      )
    } finally {
      setPending(false)
    }
  }

  const submitLabel =
    mode === 'login'
      ? t('Autentificare', 'Войти')
      : mode === 'signup'
        ? t('Creează cont', 'Создать аккаунт')
        : mode === 'forgot'
          ? t('Trimite linkul', 'Отправить ссылку')
          : t('Salvează parola', 'Сохранить пароль')

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        {(mode === 'login' || mode === 'signup') && (
          <div className="grid grid-cols-2 gap-1 rounded-lg bg-muted p-1" role="tablist">
            {(['login', 'signup'] as const).map((m) => (
              <button
                key={m}
                type="button"
                role="tab"
                aria-selected={mode === m}
                onClick={() => change(m)}
                className={
                  'rounded-md px-3 py-1.5 text-sm font-medium transition-colors ' +
                  (mode === m ? 'bg-background shadow-xs' : 'text-muted-foreground')
                }
              >
                {m === 'login' ? t('Autentificare', 'Вход') : t('Cont nou', 'Регистрация')}
              </button>
            ))}
          </div>
        )}

        <form onSubmit={submit} className="grid gap-4">
          {mode === 'signup' && (
            <div className="grid gap-1.5">
              <Label htmlFor="auth-name">{t('Nume', 'Имя')}</Label>
              <Input id="auth-name" name="name" autoComplete="name" maxLength={80} />
            </div>
          )}
          {mode !== 'reset' && (
            <div className="grid gap-1.5">
              <Label htmlFor="auth-email">E-mail</Label>
              <Input
                id="auth-email"
                name="email"
                type="email"
                required
                autoComplete="email"
              />
            </div>
          )}
          {mode !== 'forgot' && (
            <div className="grid gap-1.5">
              <Label htmlFor="auth-password">
                {mode === 'reset' ? t('Parolă nouă', 'Новый пароль') : t('Parolă', 'Пароль')}
              </Label>
              <Input
                id="auth-password"
                name="password"
                type="password"
                required
                minLength={8}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              />
              {mode !== 'login' && (
                <p className="text-xs text-muted-foreground">
                  {t('Minimum 8 caractere.', 'Минимум 8 символов.')}
                </p>
              )}
            </div>
          )}

          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}
          {message && (
            <p role="status" className="text-sm text-success">
              {message}
            </p>
          )}

          <Button type="submit" disabled={pending}>
            {pending ? t('Se procesează…', 'Подождите…') : submitLabel}
          </Button>
        </form>

        {mode === 'login' && (
          <button
            type="button"
            onClick={() => change('forgot')}
            className="text-sm text-muted-foreground underline-offset-4 hover:underline"
          >
            {t('Ai uitat parola?', 'Забыли пароль?')}
          </button>
        )}
        {mode === 'forgot' && (
          <button
            type="button"
            onClick={() => change('login')}
            className="text-sm text-muted-foreground underline-offset-4 hover:underline"
          >
            {t('Înapoi la autentificare', 'Вернуться ко входу')}
          </button>
        )}
      </DialogContent>
    </Dialog>
  )
}
