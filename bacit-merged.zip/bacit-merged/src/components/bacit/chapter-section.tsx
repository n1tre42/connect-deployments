import { useState } from 'react'
import { Check, CirclePlay, ExternalLink } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { chaptersFor, videoSources } from '@/data/chapters'
import type { Course } from '@/data/courses'
import { pick, useLang, useT } from '@/lib/i18n'
import { toggleWatched, useProgress } from '@/lib/progress'
import { cn } from '@/lib/utils'

/**
 * Short video chapters: a 15–30 minute excerpt of a public YouTube lesson,
 * played with the publisher's own player, next to independently written
 * study notes in Romanian and Russian.
 */
export function ChapterSection({ course }: { course: Course }) {
  const t = useT()
  const lang = useLang()
  const progress = useProgress()
  const chapters = chaptersFor(course.id)
  const [index, setIndex] = useState(0)
  const [playing, setPlaying] = useState<string | null>(null)
  if (!chapters.length) return null

  const chapter = chapters[Math.min(index, chapters.length - 1)]
  const source = videoSources[chapter.video]
  const done = !!progress.watched[chapter.id]
  const doneCount = chapters.filter((c) => progress.watched[c.id]).length
  const minutes = Math.round((chapter.end - chapter.start) / 60)
  const title = pick(chapter.title, lang)

  return (
    <section className="overflow-hidden rounded-2xl border bg-card shadow-xs">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b px-5 py-4">
        <div>
          <h2 className="text-lg font-bold">
            {t('Capitole video scurte', 'Короткие видеоглавы')}
          </h2>
          <p className="text-sm text-muted-foreground">
            {t(
              'Fragmente de 15–30 de minute, cu notițe în română și rusă.',
              'Фрагменты по 15–30 минут с конспектом на румынском и русском.',
            )}
          </p>
        </div>
        <span className="text-xs font-medium text-muted-foreground">
          {doneCount}/{chapters.length} {t('finalizate', 'пройдено')}
        </span>
      </div>

      <div
        role="tablist"
        aria-label={t('Capitole', 'Главы')}
        className="flex gap-1 overflow-x-auto border-b p-2"
      >
        {chapters.map((c, i) => {
          const finished = !!progress.watched[c.id]
          return (
            <button
              key={c.id}
              type="button"
              role="tab"
              aria-selected={i === index}
              onClick={() => setIndex(i)}
              className={cn(
                'flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition-colors hover:bg-accent motion-reduce:transition-none',
                i === index && 'bg-accent text-accent-foreground',
              )}
            >
              <span
                className={cn(
                  'grid size-5 place-items-center rounded-full border text-[11px]',
                  finished && 'border-success bg-success text-white',
                )}
              >
                {finished ? <Check className="size-3" aria-hidden /> : i + 1}
              </span>
              <span className="hidden sm:inline">{t('Cap.', 'Гл.')} {i + 1}</span>
            </button>
          )
        })}
      </div>

      <div className="relative aspect-video bg-black">
        {playing === chapter.id ? (
          <iframe
            key={chapter.id}
            src={`https://www.youtube-nocookie.com/embed/${chapter.video}?start=${chapter.start}&end=${chapter.end}&autoplay=1&rel=0&cc_load_policy=1`}
            title={`${chapter.title.ro} — ${source?.title ?? 'video'}`}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
            className="absolute inset-0 size-full border-0"
          />
        ) : (
          <button
            type="button"
            onClick={() => setPlaying(chapter.id)}
            className="group absolute inset-0 outline-none focus-visible:ring-[3px] focus-visible:ring-ring focus-visible:ring-inset"
            aria-label={t(`Pornește capitolul: ${title}`, `Запустить главу: ${title}`)}
          >
            <img
              src={`https://i.ytimg.com/vi/${chapter.video}/hqdefault.jpg`}
              alt=""
              loading="lazy"
              className="size-full object-cover opacity-80"
            />
            <span className="absolute inset-0 m-auto grid size-16 place-items-center rounded-full bg-primary text-primary-foreground shadow-xl transition-transform group-hover:scale-105 motion-reduce:transition-none">
              <CirclePlay className="size-8" />
            </span>
          </button>
        )}
      </div>

      <div className="grid gap-4 p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <h3 className="text-base font-bold">
              {index + 1}. {title}
            </h3>
            <p className="text-xs text-muted-foreground">
              {source?.author} · YouTube · {minutes} min · EN
            </p>
          </div>
          <Button
            variant={done ? 'secondary' : 'outline'}
            size="sm"
            aria-pressed={done}
            onClick={() => toggleWatched(chapter.id)}
            className={cn(done && 'text-success')}
          >
            <Check />
            {done ? t('Finalizat', 'Пройдено') : t('Marchează ca finalizat', 'Отметить как пройденное')}
          </Button>
        </div>

        <div className="rounded-xl bg-muted/50 p-4">
          <h4 className="mb-1.5 text-sm font-semibold">
            {t('Notițe de studiu', 'Конспект')}
          </h4>
          <p className="text-sm leading-relaxed">{pick(chapter.notes, lang)}</p>
        </div>

        <div className="flex flex-wrap gap-x-5 gap-y-2 text-sm">
          <a
            href={chapter.resource}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 text-primary hover:underline"
          >
            {t('Documentație oficială', 'Официальная документация')} <ExternalLink className="size-3.5" aria-hidden />
          </a>
          <a
            href={`https://www.youtube.com/watch?v=${chapter.video}&t=${chapter.start}s`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground hover:underline"
          >
            {t('Deschide originalul', 'Открыть оригинал')} <ExternalLink className="size-3.5" aria-hidden />
          </a>
        </div>
        <p className="text-xs text-muted-foreground">
          {t(
            'Videoclipul este încorporat cu playerul editorului; nu este descărcat sau modificat. Unele clipuri acoperă doar o parte din subiect, iar notițele și documentația completează lecția. Subtitrările depind de autor. Notițele sunt scrise independent, nu sunt o traducere sau dublare a videoclipului.',
            'Видео встроено через плеер автора; оно не скачивается и не изменяется. Некоторые ролики раскрывают только часть темы, а конспект и документация дополняют урок. Субтитры зависят от автора. Конспект написан самостоятельно и не является переводом или дубляжем видео.',
          )}
        </p>
      </div>
    </section>
  )
}
