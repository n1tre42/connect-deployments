import { useEffect, useState } from 'react'
import { Cloud, CloudOff, LogIn, LogOut, UserRound } from 'lucide-react'
import { logout } from '@netlify/identity'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { clearAuthCallback, setAuthUser, useAuth } from '@/lib/auth'
import { useT } from '@/lib/i18n'
import { useAccountSync, useSyncStatus } from '@/lib/sync'
import { AuthDialog, type AuthMode } from './auth-dialog'

/** Sign-in button / account menu. Also keeps progress in sync while signed in. */
export function AccountButton() {
  const t = useT()
  const { user, ready, callback } = useAuth()
  const sync = useSyncStatus()
  const [open, setOpen] = useState(false)
  const [mode, setMode] = useState<AuthMode>('login')
  useAccountSync()

  useEffect(() => {
    if (callback === 'recovery') {
      setMode('reset')
      setOpen(true)
    } else if (callback === 'confirmed') {
      toast.success(t('E-mail confirmat. Bine ai venit!', 'Почта подтверждена. Добро пожаловать!'))
    } else if (callback === 'invalid') {
      toast.error(
        t(
          'Linkul din e-mail a expirat sau nu este valid. Cere un link nou.',
          'Ссылка из письма устарела или недействительна. Запросите новую.',
        ),
      )
    }
    if (callback && callback !== 'recovery') clearAuthCallback()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [callback])

  function openAuth(next: AuthMode) {
    setMode(next)
    setOpen(true)
  }

  const dialog = (
    <AuthDialog
      open={open}
      onOpenChange={(value) => {
        setOpen(value)
        if (!value) clearAuthCallback()
      }}
      mode={mode}
      setMode={setMode}
    />
  )

  if (!user) {
    return (
      <>
        <Button
          variant="outline"
          size="sm"
          onClick={() => openAuth('login')}
          disabled={!ready}
          className="gap-1.5"
        >
          <LogIn aria-hidden />
          <span className="hidden sm:inline">{t('Autentificare', 'Войти')}</span>
        </Button>
        {dialog}
      </>
    )
  }

  const statusText =
    sync.status === 'syncing'
      ? t('Se salvează…', 'Сохраняется…')
      : sync.status === 'error'
        ? t('Nu s-a putut salva', 'Не удалось сохранить')
        : t('Progres salvat în cont', 'Прогресс сохранён в аккаунте')

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="gap-1.5" aria-label={t('Contul meu', 'Мой аккаунт')}>
            <UserRound aria-hidden />
            <span className="hidden max-w-32 truncate md:inline">{user.email}</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          <DropdownMenuLabel className="space-y-1">
            <span className="block truncate text-sm">{user.email}</span>
            <span className="flex items-center gap-1.5 text-xs font-normal text-muted-foreground">
              {sync.status === 'error' ? (
                <CloudOff className="size-3.5" aria-hidden />
              ) : (
                <Cloud className="size-3.5" aria-hidden />
              )}
              {statusText}
            </span>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem
            onSelect={async () => {
              try {
                await logout()
              } finally {
                setAuthUser(null)
              }
            }}
          >
            <LogOut aria-hidden /> {t('Deconectare', 'Выйти')}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      {dialog}
    </>
  )
}
