import { Languages } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { setLang, useLang } from '@/lib/i18n'

export function LanguageToggle() {
  const lang = useLang()
  const next = lang === 'ro' ? 'ru' : 'ro'
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => setLang(next)}
      aria-label={lang === 'ro' ? 'Переключить на русский язык' : 'Comută la limba română'}
      title={lang === 'ro' ? 'Русский' : 'Română'}
      className="gap-1.5 px-2 font-semibold"
    >
      <Languages aria-hidden />
      <span>{lang === 'ro' ? 'RO' : 'RU'}</span>
    </Button>
  )
}
