export type Chapter = {
  id: string
  courseId: string
  title: { ro: string; ru: string }
  notes: { ro: string; ru: string }
  /** YouTube video id; only the start–end excerpt (in seconds) is embedded. */
  video: string
  start: number
  end: number
  resource: string
}

/**
 * Short video chapters (15–30 min excerpts of public YouTube lessons) with
 * independently written study notes in Romanian and Russian. Embedded with the
 * publisher's own player; source videos are not downloaded or modified.
 */
export const videoSources: Record<string, { author: string; title: string }> = {
  "rfscVS0vtbw": { author: "freeCodeCamp.org / Mike Dane", title: "Learn Python — Full Course for Beginners" },
  "HXV3zeQKqGY": { author: "freeCodeCamp.org / Mike Dane", title: "SQL Tutorial — Full Database Course for Beginners" },
  "qiQR5rTSshw": { author: "freeCodeCamp.org / Brian Ferrill", title: "Computer Networking Course — Network Engineering" },
  "pQN-pnXPaVg": { author: "freeCodeCamp.org / Mike Dane", title: "HTML Full Course — Build a Website" },
  "1Rs2ND1ryYc": { author: "freeCodeCamp.org", title: "CSS Tutorial — Zero to Hero" },
  "y17RuWkWdn8": { author: "Web Dev Simplified", title: "Learn DOM Manipulation in 18 Minutes" },
  "2FDpVXSBRyo": { author: "Steve Griffith", title: "Service Workers — The Storage API" },
  "y2kg3MOk1sY": { author: "freeCodeCamp.org / GCFGlobal", title: "Computer & Technology Basics" },
  "MHbWOF67l3w": { author: "Passionate About Tech", title: "Windows 11 Tutorial for Beginners" },
  "eisrJIF0qbY": { author: "David Dalton", title: "Configuring NTFS Permissions" },
  "Sg93dPnPP6A": { author: "Jonathan Edwards", title: "Introducing BitLocker" },
  "-4vil3c2fa8": { author: "Britec09", title: "All You Need To Know About Windows 11 Backup" },
  "qIenQsBAg2U": { author: "Professor Messer", title: "Troubleshooting Windows — CompTIA A+ 220-1202" },
}

export const chapters: Chapter[] = [
  {
    id: "ch-py1",
    courseId: "python",
    title: { ro: "Tipuri de date și operatori", ru: "Типы данных и операторы" },
    notes: {
      ro: "Python deosebește șirurile, numerele întregi, numerele zecimale și valorile logice. input() returnează întotdeauna text: convertește-l înainte de calcule. / produce un număr zecimal, // face împărțire întreagă (rotunjire în jos), iar % returnează restul. Exercițiu: prezice tipul și valoarea expresiilor 7 // 2 și 7 / 2.",
      ru: "Python различает строки, целые и дробные числа, логические значения. input() возвращает строку: перед вычислением используйте int() или float(). / — обычное деление, // — деление с округлением вниз, % — остаток. Практика: определите тип и значение 7 // 2 и 7 / 2.",
    },
    video: "rfscVS0vtbw",
    start: 906,
    end: 2706,
    resource: "https://docs.python.org/3/tutorial/introduction.html",
  },
  {
    id: "ch-py2",
    courseId: "python",
    title: { ro: "Liste, șiruri și introducere de date", ru: "Списки, строки и ввод" },
    notes: {
      ro: "Indexarea secvențelor începe de la zero. O felie (slice) include începutul și exclude sfârșitul. Listele sunt mutabile; șirurile și tuplurile sunt imutabile. Exercițiu: creează o listă, adaugă un element cu append() și citește ultimul element cu [-1].",
      ru: "Индексы начинаются с нуля. Срез включает начало, но исключает конец. Списки изменяемы, строки и кортежи — нет. Создайте список, добавьте элемент через append() и получите последний элемент через [-1].",
    },
    video: "rfscVS0vtbw",
    start: 3157,
    end: 4737,
    resource: "https://docs.python.org/3/library/stdtypes.html",
  },
  {
    id: "ch-py3",
    courseId: "python",
    title: { ro: "Funcții și decizii", ru: "Функции и условия" },
    notes: {
      ro: "Definește comportament reutilizabil cu def. Instrucțiunea return trimite o valoare apelantului; print doar o afișează. if/elif/else alege o ramură pe baza expresiilor logice. Indentarea delimitează blocurile. Exercițiu: scrie o funcție care returnează numărul mai mare dintre două.",
      ru: "Функция определяется через def. return возвращает результат вызывающему коду; print только выводит его. if/elif/else выбирает ветвь по логическому условию. Отступы задают блоки. Напишите функцию, возвращающую большее из двух чисел.",
    },
    video: "rfscVS0vtbw",
    start: 5055,
    end: 6847,
    resource: "https://docs.python.org/3/tutorial/controlflow.html",
  },
  {
    id: "ch-py4",
    courseId: "python",
    title: { ro: "Bucle și iterație", ru: "Циклы и итерация" },
    notes: {
      ro: "Bucla while se repetă cât timp condiția este adevărată. Bucla for parcurge un obiect iterabil. range(1, 5) produce 1, 2, 3, 4. break iese din buclă; continue sare peste restul iterației curente. Urmărește valorile variabilelor pe hârtie pentru a găsi erorile de limită (off-by-one).",
      ru: "while повторяется, пока условие истинно. for перебирает итерируемый объект. range(1, 5) даёт 1, 2, 3, 4. break прерывает цикл, continue переходит к следующей итерации. Проследите значения переменных, чтобы найти ошибку границ.",
    },
    video: "rfscVS0vtbw",
    start: 8053,
    end: 9680,
    resource: "https://docs.python.org/3/tutorial/controlflow.html#for-statements",
  },
  {
    id: "ch-py5",
    courseId: "python",
    title: { ro: "Fișiere și tratarea excepțiilor", ru: "Файлы и исключения" },
    notes: {
      ro: "Folosește with open(...) pentru a închide fișierele în siguranță. Modul r citește; w înlocuiește conținutul existent; a adaugă la sfârșit. Prinde excepții specifice, precum ValueError sau FileNotFoundError. Blocul finally se execută indiferent dacă a apărut o excepție. Nu ignora niciodată o eroare în tăcere când apelantul trebuie să o cunoască.",
      ru: "with open(...) гарантирует закрытие файла. Режим r читает, w заменяет содержимое, a дописывает. Перехватывайте конкретные исключения: ValueError или FileNotFoundError. finally выполняется независимо от ошибки. Не скрывайте ошибку, если она важна вызывающему коду.",
    },
    video: "rfscVS0vtbw",
    start: 11057,
    end: 12493,
    resource: "https://docs.python.org/3/tutorial/errors.html",
  },
  {
    id: "ch-py6",
    courseId: "python",
    title: { ro: "Module și structura codului", ru: "Модули и структура кода" },
    notes: {
      ro: "Importă cod reutilizabil cu import sau from ... import. Biblioteca standard include math, random și datetime. Un modul este un fișier Python. Folosește nume descriptive, docstring-uri și funcții mici. Recapitulează diferența dintre erorile de sintaxă, excepțiile la execuție și logica incorectă.",
      ru: "Подключайте код через import или from ... import. В стандартной библиотеке есть math, random, datetime. Модуль — это файл Python. Используйте понятные имена, docstring и небольшие функции. Различайте синтаксические ошибки, исключения времени выполнения и логические ошибки.",
    },
    video: "rfscVS0vtbw",
    start: 12493,
    end: 13436,
    resource: "https://docs.python.org/3/tutorial/modules.html",
  },
  {
    id: "ch-db1",
    courseId: "baze-de-date",
    title: { ro: "Fundamentele relaționale", ru: "Основы реляционных баз" },
    notes: {
      ro: "O bază de date relațională stochează rânduri în tabele. O cheie primară identifică unic un rând; o cheie externă face referire la altă cheie. Modelează o relație unu-la-mulți punând cheia externă pe partea „mulți”. Reduce faptele repetate prin normalizare.",
      ru: "Реляционная база хранит строки в таблицах. Первичный ключ уникально определяет строку; внешний ссылается на ключ другой таблицы. В связи один-ко-многим внешний ключ располагается на стороне «много». Нормализация уменьшает дублирование фактов.",
    },
    video: "HXV3zeQKqGY",
    start: 156,
    end: 1390,
    resource: "https://www.postgresql.org/docs/current/ddl.html",
  },
  {
    id: "ch-db2",
    courseId: "baze-de-date",
    title: { ro: "Tabele, chei și constrângeri", ru: "Таблицы, ключи и ограничения" },
    notes: {
      ro: "CREATE TABLE definește un tabel. NOT NULL interzice valorile lipsă, UNIQUE previne duplicatele, iar CHECK validează o condiție. Alege tipuri de date potrivite. ALTER modifică o definiție; DROP șterge un obiect. Exercițiu: creează tabelele students și enrollments.",
      ru: "CREATE TABLE определяет таблицу. NOT NULL запрещает отсутствие значения, UNIQUE — дубликаты, CHECK проверяет условие. Выбирайте подходящие типы данных. ALTER изменяет структуру, DROP удаляет объект. Создайте таблицы students и enrollments.",
    },
    video: "HXV3zeQKqGY",
    start: 4549,
    end: 6349,
    resource: "https://www.postgresql.org/docs/current/ddl-constraints.html",
  },
  {
    id: "ch-db3",
    courseId: "baze-de-date",
    title: { ro: "SELECT, filtrare și sortare", ru: "SELECT, фильтрация и сортировка" },
    notes: {
      ro: "SELECT alege coloanele, WHERE filtrează rândurile, iar ORDER BY sortează rezultatul. Folosește IS NULL, nu = NULL. Pune între paranteze combinațiile de AND și OR. DISTINCT elimină rândurile duplicate din rezultat. Exercițiu: scrie o interogare care listează studenții cu punctaje peste 80.",
      ru: "SELECT выбирает столбцы, WHERE фильтрует строки, ORDER BY сортирует результат. Проверяйте пропуски через IS NULL, а не = NULL. Используйте скобки с AND и OR. DISTINCT удаляет повторы. Выведите студентов с результатом выше 80.",
    },
    video: "HXV3zeQKqGY",
    start: 6971,
    end: 7871,
    resource: "https://www.postgresql.org/docs/current/queries.html",
  },
  {
    id: "ch-db4",
    courseId: "baze-de-date",
    title: { ro: "Agregări și operații pe mulțimi", ru: "Агрегаты и операции с множествами" },
    notes: {
      ro: "COUNT, SUM și AVG sintetizează datele. GROUP BY creează grupuri; HAVING filtrează grupurile după agregare. UNION combină seturi de rezultate compatibile și elimină duplicatele. UNION ALL le păstrează. COUNT(coloană) ignoră valorile NULL.",
      ru: "COUNT, SUM и AVG обобщают данные. GROUP BY создаёт группы, HAVING фильтрует их после агрегации. UNION объединяет совместимые результаты и убирает повторы; UNION ALL сохраняет их. COUNT(column) не учитывает NULL.",
    },
    video: "HXV3zeQKqGY",
    start: 9027,
    end: 10827,
    resource: "https://www.postgresql.org/docs/current/functions-aggregate.html",
  },
  {
    id: "ch-db5",
    courseId: "baze-de-date",
    title: { ro: "JOIN-uri și subinterogări", ru: "JOIN и подзапросы" },
    notes: {
      ro: "INNER JOIN returnează rândurile care se potrivesc. LEFT JOIN păstrează fiecare rând din stânga, folosind NULL pentru potrivirile lipsă din dreapta. O subinterogare furnizează o valoare sau un set interogării exterioare. Atenție: un filtru WHERE pe tabelul din dreapta poate elimina rândurile din stânga fără potrivire.",
      ru: "INNER JOIN возвращает совпадения. LEFT JOIN сохраняет все строки слева и подставляет NULL при отсутствии совпадения справа. Подзапрос передаёт значение или набор во внешний запрос. Фильтр WHERE по правой таблице может удалить несовпавшие строки.",
    },
    video: "HXV3zeQKqGY",
    start: 10896,
    end: 12112,
    resource: "https://www.postgresql.org/docs/current/queries-table-expressions.html",
  },
  {
    id: "ch-db6",
    courseId: "baze-de-date",
    title: { ro: "Modificarea datelor și integritatea", ru: "Изменение данных и целостность" },
    notes: {
      ro: "INSERT adaugă rânduri; UPDATE le modifică; DELETE le șterge. Fără WHERE, UPDATE și DELETE afectează toate rândurile. O tranzacție grupează modificările: COMMIT le salvează, iar ROLLBACK anulează munca nefinalizată. O cheie externă previne referințele orfane.",
      ru: "INSERT добавляет строки, UPDATE изменяет, DELETE удаляет. Без WHERE команды UPDATE и DELETE затрагивают все строки. Транзакция объединяет изменения: COMMIT сохраняет, ROLLBACK отменяет незафиксированное. Внешний ключ предотвращает ссылки на несуществующие записи.",
    },
    video: "HXV3zeQKqGY",
    start: 6491,
    end: 7717,
    resource: "https://www.postgresql.org/docs/current/tutorial-transactions.html",
  },
  {
    id: "ch-net1",
    courseId: "retelistica",
    title: { ro: "Rețele și topologii", ru: "Сети и топологии" },
    notes: {
      ro: "LAN conectează dispozitive într-o zonă locală; WAN conectează rețele îndepărtate. Într-o topologie stea, dispozitivele se conectează la un switch central. Înțelege diferența dintre lățimea de bandă și latență, precum și dintre modelul client-server și peer-to-peer.",
      ru: "LAN объединяет устройства в локальной области; WAN соединяет удалённые сети. В топологии «звезда» устройства подключены к центральному коммутатору. Различайте пропускную способность и задержку, клиент-серверную и одноранговую модели.",
    },
    video: "qiQR5rTSshw",
    start: 6208,
    end: 7362,
    resource: "https://www.cisco.com/site/us/en/learn/topics/networking/what-is-computer-networking.html",
  },
  {
    id: "ch-net2",
    courseId: "retelistica",
    title: { ro: "Modelele OSI și TCP/IP", ru: "Модели OSI и TCP/IP" },
    notes: {
      ro: "Modelul OSI separă șapte straturi. Switch-urile transmit de obicei cadre Ethernet la nivelul 2; routerele dirijează pachete IP la nivelul 3. TCP oferă transport ordonat și fiabil; UDP are cost redus, dar fără garanția livrării.",
      ru: "Модель OSI разделяет взаимодействие на семь уровней. Коммутаторы обычно пересылают кадры Ethernet на уровне 2, маршрутизаторы — IP-пакеты на уровне 3. TCP обеспечивает надёжную упорядоченную доставку, UDP не гарантирует её.",
    },
    video: "qiQR5rTSshw",
    start: 27813,
    end: 28715,
    resource: "https://developer.mozilla.org/en-US/docs/Glossary/TCP",
  },
  {
    id: "ch-net3",
    courseId: "retelistica",
    title: { ro: "IPv4, IPv6 și subrețele", ru: "IPv4, IPv6 и подсети" },
    notes: {
      ro: "Adresele IPv4 au 32 de biți; IPv6 folosește 128. Lungimea prefixului identifică biții de rețea. O subrețea IPv4 /24 are 256 de adrese, de obicei 254 atribuibile gazdelor. Gateway-ul implicit dirijează traficul în afara subrețelei locale.",
      ru: "В IPv4 адрес содержит 32 бита, в IPv6 — 128. Длина префикса определяет сетевую часть. Подсеть IPv4 /24 содержит 256 адресов, обычно 254 адреса узлов. Шлюз по умолчанию направляет трафик за пределы локальной подсети.",
    },
    video: "qiQR5rTSshw",
    start: 6986,
    end: 8770,
    resource: "https://developer.mozilla.org/en-US/docs/Glossary/IP_Address",
  },
  {
    id: "ch-net4",
    courseId: "retelistica",
    title: { ro: "Echipamente, cabluri și wireless", ru: "Оборудование, кабели и Wi-Fi" },
    notes: {
      ro: "Un switch conectează dispozitivele dintr-un LAN; un router conectează rețele IP; un punct de acces conectează clienții wireless. Ethernetul pe cupru folosește de obicei conectori RJ-45. Fibra optică rezistă la interferențele electromagnetice. Alege cablul în funcție de capacitatea și distanța necesare.",
      ru: "Коммутатор соединяет узлы LAN, маршрутизатор — IP-сети, точка доступа — беспроводные устройства. Медный Ethernet обычно использует RJ-45. Оптоволокно устойчиво к электромагнитным помехам. Подбирайте кабель с учётом скорости и расстояния.",
    },
    video: "qiQR5rTSshw",
    start: 4952,
    end: 6208,
    resource: "https://www.cisco.com/site/us/en/learn/topics/networking/what-is-a-network-switch.html",
  },
  {
    id: "ch-net5",
    courseId: "retelistica",
    title: { ro: "DNS, DHCP și servicii de rețea", ru: "DNS, DHCP и сетевые службы" },
    notes: {
      ro: "DNS rezolvă nume în adrese. DHCP atribuie automat setările IP. HTTPS folosește portul TCP 443, HTTP portul 80, iar SSH portul 22. Fă diferența dintre o eroare de rezolvare a numelui și o eroare de conectivitate IP.",
      ru: "DNS преобразует имена в адреса. DHCP автоматически выдаёт сетевые настройки. HTTPS использует TCP-порт 443, HTTP — 80, SSH — 22. Различайте сбой разрешения имён и отсутствие IP-связности.",
    },
    video: "qiQR5rTSshw",
    start: 912,
    end: 2712,
    resource: "https://developer.mozilla.org/en-US/docs/Glossary/DNS",
  },
  {
    id: "ch-net6",
    courseId: "retelistica",
    title: { ro: "Securitate și depanare", ru: "Безопасность и диагностика" },
    notes: {
      ro: "Folosește WPA3 acolo unde este disponibil, parole puternice și principiul privilegiului minim. ping verifică accesibilitatea ICMP; traceroute identifică salturile; ipconfig afișează configurația locală; nslookup verifică DNS. Începe depanarea cu legătura fizică, înainte de a schimba setările software.",
      ru: "Применяйте WPA3 при поддержке, сложные пароли и минимальные привилегии. ping проверяет доступность по ICMP, traceroute показывает узлы маршрута, ipconfig — настройки, nslookup — DNS. Начинайте диагностику с физического подключения.",
    },
    video: "qiQR5rTSshw",
    start: 22962,
    end: 24219,
    resource: "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
  },
  {
    id: "ch-web1",
    courseId: "html5",
    title: { ro: "HTML semantic și structura documentului", ru: "Семантический HTML" },
    notes: {
      ro: "Folosește elemente semantice precum main, nav, article și footer pentru a exprima structura documentului. Titlurile formează o ierarhie. Asociază etichetele cu controalele de formular. Textul alt semnificativ descrie imaginile utile; imaginile decorative folosesc un atribut alt gol.",
      ru: "Семантические main, nav, article и footer описывают структуру. Заголовки образуют иерархию. Связывайте label с полями формы. Для содержательных изображений задавайте осмысленный alt, для декоративных — пустой.",
    },
    video: "pQN-pnXPaVg",
    start: 2887,
    end: 4053,
    resource: "https://developer.mozilla.org/en-US/docs/Web/HTML",
  },
  {
    id: "ch-web2",
    courseId: "html5",
    title: { ro: "Formulare, media și grafică", ru: "Формы, медиа и графика" },
    notes: {
      ro: "Folosește tipurile input și atributul required pentru validarea nativă, apoi validează din nou pe server. Audio și video au controale native. Canvas desenează o imagine bitmap prin JavaScript; SVG descrie forme vectoriale scalabile.",
      ru: "Типы input и required обеспечивают встроенную проверку; сервер должен проверить данные повторно. audio и video поддерживают controls. Canvas рисует растровое изображение через JavaScript, SVG описывает масштабируемую векторную графику.",
    },
    video: "pQN-pnXPaVg",
    start: 6294,
    end: 7352,
    resource: "https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input",
  },
  {
    id: "ch-web3",
    courseId: "html5",
    title: { ro: "Selectori CSS și modelul casetă", ru: "Селекторы CSS и блочная модель" },
    notes: {
      ro: "Cascada rezolvă declarațiile concurente după origine, importanță, specificitate și ordine. Modelul casetă (box model) constă din conținut, padding, bordură și margine. box-sizing: border-box include padding-ul și bordura în lățimea declarată.",
      ru: "Каскад учитывает источник, важность, специфичность и порядок. Блочная модель включает content, padding, border и margin. box-sizing: border-box включает padding и border в объявленную ширину.",
    },
    video: "1Rs2ND1ryYc",
    start: 10147,
    end: 11717,
    resource: "https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_box_model",
  },
  {
    id: "ch-web4",
    courseId: "html5",
    title: { ro: "Machete adaptive și animații", ru: "Адаптивные макеты и анимация" },
    notes: {
      ro: "Folosește media queries pentru a adapta stilurile la condițiile ferestrei de vizualizare. Flexbox așază elementele pe o axă principală; Grid permite rânduri și coloane. Preferă transform și opacity pentru animații și respectă prefers-reduced-motion.",
      ru: "Медиазапросы адаптируют стили к условиям экрана. Flexbox располагает элементы вдоль основной оси, Grid задаёт строки и столбцы. Для анимации используйте transform и opacity, учитывайте prefers-reduced-motion.",
    },
    video: "1Rs2ND1ryYc",
    start: 14896,
    end: 16393,
    resource: "https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout",
  },
  {
    id: "ch-web5",
    courseId: "html5",
    title: { ro: "JavaScript, DOM și evenimente", ru: "JavaScript, DOM и события" },
    notes: {
      ro: "let declară variabile cu domeniu de bloc; const împiedică reatribuirea. querySelector găsește un element. addEventListener atașează un handler. preventDefault anulează o acțiune implicită a browserului. Folosește textContent pentru text nesigur, în loc să inserezi HTML.",
      ru: "let объявляет переменную с блочной областью, const запрещает переназначение. querySelector находит элемент, addEventListener подключает обработчик, preventDefault отменяет стандартное действие. Для непроверенного текста используйте textContent.",
    },
    video: "y17RuWkWdn8",
    start: 0,
    end: 1117,
    resource: "https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model",
  },
  {
    id: "ch-web6",
    courseId: "html5",
    title: { ro: "Ciclul de viață al aplicației și stocarea în browser", ru: "Жизненный цикл и хранилища" },
    notes: {
      ro: "localStorage păstrează valori text pentru o origine, iar sessionStorage este limitat la sesiunea unei file. Un service worker poate intercepta cereri și permite cache offline. Geolocația necesită permisiunea utilizatorului și un context securizat. Nu stoca niciodată secrete în stocarea browserului.",
      ru: "localStorage сохраняет строки для origin, sessionStorage ограничен сессией вкладки. Service worker может перехватывать запросы и обеспечивать офлайн-кеш. Geolocation требует разрешения и безопасного контекста. Не храните секреты в браузерном хранилище.",
    },
    video: "2FDpVXSBRyo",
    start: 0,
    end: 1186,
    resource: "https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps",
  },
  {
    id: "ch-dev1",
    courseId: "configurare-dispozitive",
    title: { ro: "Hardware și periferice", ru: "Оборудование и периферия" },
    notes: {
      ro: "CPU execută instrucțiuni, RAM păstrează datele active, iar stocarea reține fișierele. SSD-urile nu au piese în mișcare. Potrivește conectorii de afișare și ai perifericelor cu capacitatea dispozitivului. Oprește alimentarea și respectă măsurile de protecție împotriva descărcărilor electrostatice înainte de service.",
      ru: "CPU выполняет инструкции, RAM хранит рабочие данные, накопитель сохраняет файлы. SSD не имеет движущихся частей. Подбирайте разъёмы по возможностям устройств. Перед обслуживанием отключайте питание и соблюдайте защиту от статического электричества.",
    },
    video: "y2kg3MOk1sY",
    start: 0,
    end: 953,
    resource: "https://learn.microsoft.com/en-us/windows/client-management/",
  },
  {
    id: "ch-dev2",
    courseId: "configurare-dispozitive",
    title: { ro: "Sisteme de operare și instalare", ru: "ОС и первоначальная настройка" },
    notes: {
      ro: "Un sistem de operare gestionează resursele și oferă servicii aplicațiilor. Driverele permit sistemului să comunice cu hardware-ul. Menține sistemele și driverele acceptate la zi. Folosește surse oficiale pentru drivere și verifică cerințele înainte de a instala programe.",
      ru: "Операционная система управляет ресурсами и поддерживает приложения. Драйвер обеспечивает взаимодействие ОС с оборудованием. Обновляйте поддерживаемую ОС и драйверы, используйте официальные источники и проверяйте требования перед установкой.",
    },
    video: "MHbWOF67l3w",
    start: 0,
    end: 1213,
    resource: "https://learn.microsoft.com/en-us/windows/deployment/",
  },
  {
    id: "ch-dev3",
    courseId: "configurare-dispozitive",
    title: { ro: "Fișiere, stocare și permisiuni", ru: "Файлы, диски и права доступа" },
    notes: {
      ro: "NTFS acceptă liste de control al accesului (ACL) și funcții indisponibile în FAT32. FAT32 limitează fișierele individuale la sub 4 GiB. Aplică privilegiul minim folderelor partajate. Accesul efectiv prin rețea depinde atât de permisiunile de partajare, cât și de cele ale sistemului de fișiere.",
      ru: "NTFS поддерживает списки доступа и функции, которых нет в FAT32. В FAT32 размер одного файла меньше 4 ГиБ. Выдавайте минимальные права на общие папки. Итоговый сетевой доступ зависит и от прав общего ресурса, и от файловой системы.",
    },
    video: "eisrJIF0qbY",
    start: 0,
    end: 1068,
    resource: "https://learn.microsoft.com/en-us/windows-server/storage/file-server/ntfs-overview",
  },
  {
    id: "ch-dev4",
    courseId: "configurare-dispozitive",
    title: { ro: "Conturi și securitatea dispozitivului", ru: "Учётные записи и безопасность" },
    notes: {
      ro: "Folosește un cont de utilizator standard pentru munca obișnuită. MFA combină factori independenți de tipuri diferite. BitLocker criptează stocarea; păstrează cheia de recuperare într-un loc sigur. Blocarea ecranului protejează o sesiune nesupravegheată, iar actualizările și protecția endpoint reduc amenințările cunoscute.",
      ru: "Для обычной работы используйте стандартную учётную запись. MFA сочетает независимые типы факторов. BitLocker шифрует накопитель; храните ключ восстановления безопасно. Блокировка защищает оставленный сеанс, обновления и антивирус уменьшают угрозы.",
    },
    video: "Sg93dPnPP6A",
    start: 0,
    end: 912,
    resource: "https://learn.microsoft.com/en-us/windows/security/operating-system-security/data-protection/bitlocker/",
  },
  {
    id: "ch-dev5",
    courseId: "configurare-dispozitive",
    title: { ro: "Copii de rezervă și recuperare", ru: "Резервное копирование и восстановление" },
    notes: {
      ro: "O copie de rezervă este o copie separată, recuperabilă; sincronizarea singură nu este backup. O copie completă salvează toate datele selectate; una incrementală salvează modificările de la ultima copie. Testează periodic restaurarea. System Restore nu înlocuiește copia de rezervă a fișierelor personale.",
      ru: "Резервная копия — отдельная восстанавливаемая копия; синхронизация не заменяет её. Полная копия содержит все выбранные данные, инкрементная — изменения с последнего копирования. Проверяйте восстановление. System Restore не заменяет копии личных файлов.",
    },
    video: "-4vil3c2fa8",
    start: 0,
    end: 1043,
    resource: "https://support.microsoft.com/en-us/windows/recovery-options-in-windows-31ce2444-7de3-818c-d626-e3b5a3024da5",
  },
  {
    id: "ch-dev6",
    courseId: "configurare-dispozitive",
    title: { ro: "Bazele depanării", ru: "Основы диагностики" },
    notes: {
      ro: "Identifică simptomele, adună dovezi, formulează o ipoteză, testează o singură modificare și documentează rezultatele. Task Manager arată procesele în execuție. Device Manager afișează starea dispozitivelor și a driverelor. Event Viewer înregistrează evenimentele sistemului. Safe Mode încarcă un set minim de drivere.",
      ru: "Опишите симптомы, соберите данные, сформулируйте гипотезу, проверьте одно изменение и запишите результат. Task Manager показывает процессы, Device Manager — устройства и драйверы, Event Viewer — события. Безопасный режим загружает минимальный набор драйверов.",
    },
    video: "qIenQsBAg2U",
    start: 0,
    end: 1050,
    resource: "https://learn.microsoft.com/en-us/troubleshoot/windows-client/",
  },
]

export function chaptersFor(courseId: string) {
  return chapters.filter((c) => c.courseId === courseId)
}
