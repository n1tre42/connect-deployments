export type GlossaryTerm = {
  term: string
  /** Russian display name; only set when the term is a phrase rather than code. */
  termRu?: string
  course: string
  module: string
  definition: string
  /** Russian definition. Terms without one fall back to the Romanian text. */
  definitionRu?: string
  example?: string
}

export const glossary: GlossaryTerm[] = [
  {
    "term": "Tip de date (data type)",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Categoria unei valori, care determină ce operații se pot face cu ea: int, float, str, bool, list, tuple, dict, set.",
    "example": "type(3.0)  # <class 'float'>"
  },
  {
    "term": "Conversie de tip (type casting)",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Transformarea explicită a unei valori dintr-un tip în altul cu funcții precum int(), float(), str(), bool().",
    "example": "int(\"42\") + 1  # 43"
  },
  {
    "term": "Operator de precedență",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Ordinea în care se evaluează operatorii: ** înaintea lui * / // %, apoi + -, apoi comparațiile, apoi not, and, or.",
    "example": "2 + 3 * 2 ** 2  # 14"
  },
  {
    "term": "Mutabil / imutabil",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Un obiect mutabil (list, dict, set) poate fi modificat pe loc; unul imutabil (int, str, tuple) nu, orice „modificare” creează un obiect nou."
  },
  {
    "term": "Slicing (feliere)",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Extragerea unei porțiuni dintr-o secvență cu sintaxa [start:stop:pas]; stop nu este inclus.",
    "example": "\"Python\"[1:4]  # \"yth\""
  },
  {
    "term": "Instrucțiune condițională",
    "course": "python",
    "module": "02-control-flux",
    "definition": "Structura if / elif / else, care execută un bloc de cod doar dacă o condiție este adevărată."
  },
  {
    "term": "Buclă (iterație)",
    "course": "python",
    "module": "02-control-flux",
    "definition": "Repetarea unui bloc de cod: for parcurge o secvență, while repetă cât timp condiția este adevărată.",
    "example": "for i in range(3): print(i)"
  },
  {
    "term": "break / continue / pass",
    "course": "python",
    "module": "02-control-flux",
    "definition": "break iese din buclă, continue trece la iterația următoare, pass este o instrucțiune goală folosită ca loc rezervat."
  },
  {
    "term": "Mod de deschidere a fișierului",
    "course": "python",
    "module": "03-intrare-iesire",
    "definition": "Al doilea argument al lui open(): \"r\" citire, \"w\" scriere (golește fișierul), \"a\" adăugare la final, \"x\" creare exclusivă, \"b\" binar."
  },
  {
    "term": "f-string",
    "course": "python",
    "module": "03-intrare-iesire",
    "definition": "Șir prefixat cu f în care expresiile dintre acolade sunt evaluate și formatate.",
    "example": "f\"{3.14159:.2f}\"  # \"3.14\""
  },
  {
    "term": "Docstring",
    "course": "python",
    "module": "04-documentare-structura",
    "definition": "Șir între ghilimele triple, plasat imediat după definiția unei funcții, clase sau modul, care îi descrie scopul. Este accesibil prin help() și __doc__.",
    "definitionRu": "Документирует модуль, класс или функцию первым строковым литералом."
  },
  {
    "term": "Parametru implicit",
    "course": "python",
    "module": "04-documentare-structura",
    "definition": "Parametru al unei funcții cu o valoare predefinită, folosită când argumentul lipsește la apel.",
    "example": "def salut(nume=\"Ana\"): ..."
  },
  {
    "term": "Excepție",
    "course": "python",
    "module": "05-depanare-erori",
    "definition": "Eroare apărută în timpul execuției (de ex. ValueError, ZeroDivisionError), care poate fi tratată cu try / except."
  },
  {
    "term": "Eroare de sintaxă / de execuție / logică",
    "course": "python",
    "module": "05-depanare-erori",
    "definition": "Sintaxă: codul nu respectă regulile limbajului și nu pornește. Execuție: apare o excepție la rulare. Logică: programul rulează, dar dă un rezultat greșit."
  },
  {
    "term": "Modul",
    "course": "python",
    "module": "06-module-instrumente",
    "definition": "Fișier .py cu funcții, clase și variabile reutilizabile, încărcat cu import. Biblioteca standard include math, random, datetime, os, sys."
  },
  {
    "term": "Cheie primară (primary key)",
    "course": "baze-de-date",
    "module": "01-proiectare",
    "definition": "Coloana sau combinația de coloane care identifică unic fiecare rând al unui tabel. Nu poate conține NULL sau duplicate.",
    "definitionRu": "Уникально определяет строку и не допускает NULL."
  },
  {
    "term": "Cheie externă (foreign key)",
    "course": "baze-de-date",
    "module": "01-proiectare",
    "definition": "Coloană care referă cheia primară a altui tabel și impune integritatea referențială între cele două.",
    "definitionRu": "Обеспечивает ссылочную целостность на потенциальный ключ связанной таблицы."
  },
  {
    "term": "Normalizare",
    "course": "baze-de-date",
    "module": "01-proiectare",
    "definition": "Procesul de organizare a tabelelor pentru a reduce redundanța: 1NF (valori atomice), 2NF (fără dependențe parțiale), 3NF (fără dependențe tranzitive).",
    "definitionRu": "Уменьшает дублирование фактов и аномалии обновления таблиц."
  },
  {
    "term": "Diagramă entitate-relație (ERD)",
    "course": "baze-de-date",
    "module": "01-proiectare",
    "definition": "Reprezentare grafică a entităților (tabelelor), atributelor și relațiilor dintre ele: unu-la-unu, unu-la-mulți, mulți-la-mulți."
  },
  {
    "term": "DDL (Data Definition Language)",
    "course": "baze-de-date",
    "module": "02-obiecte",
    "definition": "Comenzile care definesc structura bazei de date: CREATE, ALTER, DROP, TRUNCATE."
  },
  {
    "term": "Constrângere (constraint)",
    "course": "baze-de-date",
    "module": "02-obiecte",
    "definition": "Regulă impusă datelor dintr-o coloană: PRIMARY KEY, FOREIGN KEY, UNIQUE, NOT NULL, CHECK, DEFAULT."
  },
  {
    "term": "Index",
    "course": "baze-de-date",
    "module": "02-obiecte",
    "definition": "Structură care accelerează căutarea rândurilor după una sau mai multe coloane, în schimbul unui cost la scriere."
  },
  {
    "term": "Vedere (view)",
    "course": "baze-de-date",
    "module": "02-obiecte",
    "definition": "Interogare SELECT salvată sub un nume, folosită ca un tabel virtual."
  },
  {
    "term": "Funcție agregată",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Funcție care calculează o singură valoare dintr-un set de rânduri: COUNT, SUM, AVG, MIN, MAX."
  },
  {
    "term": "JOIN",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Combinarea rândurilor din două tabele după o condiție: INNER JOIN (doar potriviri), LEFT/RIGHT JOIN (tot dintr-o parte), CROSS JOIN (toate combinațiile)."
  },
  {
    "term": "GROUP BY / HAVING",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "GROUP BY grupează rândurile cu aceleași valori; HAVING filtrează grupurile după rezultatul funcțiilor agregate."
  },
  {
    "term": "DML (Data Manipulation Language)",
    "course": "baze-de-date",
    "module": "04-manipulare",
    "definition": "Comenzile care modifică datele: INSERT, UPDATE, DELETE (și SELECT pentru citire)."
  },
  {
    "term": "Tranzacție",
    "course": "baze-de-date",
    "module": "04-manipulare",
    "definition": "Grup de operații executate ca o singură unitate: fie toate reușesc (COMMIT), fie niciuna (ROLLBACK)."
  },
  {
    "term": "NULL",
    "course": "baze-de-date",
    "module": "05-depanare",
    "definition": "Marcaj pentru o valoare lipsă sau necunoscută. Se testează cu IS NULL / IS NOT NULL, nu cu =."
  },
  {
    "term": "LAN / WAN",
    "course": "retelistica",
    "module": "01-infrastructura",
    "definition": "LAN: rețea locală (o clădire, o școală). WAN: rețea pe arie largă care leagă mai multe LAN-uri, de exemplu internetul."
  },
  {
    "term": "Adresă IPv4",
    "course": "retelistica",
    "module": "01-infrastructura",
    "definition": "Adresă logică de 32 de biți, scrisă ca patru octeți zecimali (192.168.1.10), formată din partea de rețea și partea de gazdă.",
    "definitionRu": "Использует 32-битные адреса."
  },
  {
    "term": "Mască de subrețea / CIDR",
    "course": "retelistica",
    "module": "01-infrastructura",
    "definition": "Indică câți biți ai adresei aparțin rețelei: 255.255.255.0 = /24. Gazde utilizabile: 2^(32−prefix) − 2."
  },
  {
    "term": "Gateway implicit",
    "course": "retelistica",
    "module": "01-infrastructura",
    "definition": "Adresa routerului prin care un dispozitiv trimite traficul destinat altor rețele.",
    "definitionRu": "Получает трафик, предназначенный IP-сетям вне локальной подсети."
  },
  {
    "term": "Switch",
    "course": "retelistica",
    "module": "02-hardware",
    "definition": "Dispozitiv de nivel 2 care conectează gazdele dintr-un LAN și trimite cadrele doar spre portul destinatarului, după adresa MAC.",
    "definitionRu": "Обычно пересылает кадры Ethernet по таблице MAC-адресов."
  },
  {
    "term": "Router",
    "course": "retelistica",
    "module": "02-hardware",
    "definition": "Dispozitiv de nivel 3 care direcționează pachetele între rețele diferite, pe baza adreselor IP și a tabelei de rutare.",
    "definitionRu": "Пересылает IP-пакеты между разными сетями."
  },
  {
    "term": "Adresă MAC",
    "course": "retelistica",
    "module": "02-hardware",
    "definition": "Adresă fizică de 48 de biți, unică, atribuită plăcii de rețea de producător."
  },
  {
    "term": "Modelul OSI",
    "course": "retelistica",
    "module": "03-protocoale-servicii",
    "definition": "Model conceptual în 7 niveluri: Fizic, Legătură de date, Rețea, Transport, Sesiune, Prezentare, Aplicație."
  },
  {
    "term": "TCP / UDP",
    "course": "retelistica",
    "module": "03-protocoale-servicii",
    "definition": "Protocoale de transport. TCP: orientat pe conexiune, sigur, ordonat. UDP: fără conexiune, rapid, fără garanția livrării."
  },
  {
    "term": "DNS",
    "course": "retelistica",
    "module": "03-protocoale-servicii",
    "definition": "Serviciul care traduce nume de domeniu (bacit.md) în adrese IP. Folosește portul 53.",
    "definitionRu": "Преобразует доменные имена в IP-адреса."
  },
  {
    "term": "DHCP",
    "course": "retelistica",
    "module": "03-protocoale-servicii",
    "definition": "Protocol care atribuie automat adresa IP, masca, gateway-ul și serverele DNS dispozitivelor din rețea.",
    "definitionRu": "Автоматически выдаёт клиентам сетевые настройки в аренду."
  },
  {
    "term": "Firewall",
    "course": "retelistica",
    "module": "04-securitate",
    "definition": "Sistem hardware sau software care permite sau blochează traficul pe baza unor reguli (adrese, porturi, protocoale)."
  },
  {
    "term": "VPN",
    "course": "retelistica",
    "module": "04-securitate",
    "definition": "Rețea privată virtuală: tunel criptat peste o rețea publică, care protejează traficul."
  },
  {
    "term": "ping / tracert",
    "course": "retelistica",
    "module": "05-depanare",
    "definition": "ping testează dacă o gazdă răspunde (ICMP Echo); tracert / traceroute arată routerele prin care trece pachetul până la destinație."
  },
  {
    "term": "APIPA",
    "course": "retelistica",
    "module": "05-depanare",
    "definition": "Adresă 169.254.x.x atribuită automat de Windows când serverul DHCP nu răspunde — semn de problemă de conectivitate."
  },
  {
    "term": "Element semantic",
    "course": "html5",
    "module": "02-interfata-html5",
    "definition": "Element care descrie rolul conținutului: <header>, <nav>, <main>, <article>, <section>, <aside>, <footer>."
  },
  {
    "term": "Validare a formularelor",
    "course": "html5",
    "module": "02-interfata-html5",
    "definition": "Verificarea datelor înainte de trimitere, cu atribute (required, pattern, min, max, type=\"email\") sau cu JavaScript."
  },
  {
    "term": "<canvas>",
    "course": "html5",
    "module": "02-interfata-html5",
    "definition": "Suprafață de desen bitmap controlată din JavaScript prin contextul 2D (getContext(\"2d\")).",
    "definitionRu": "Предоставляет растровую поверхность для рисования через JavaScript."
  },
  {
    "term": "SVG",
    "course": "html5",
    "module": "02-interfata-html5",
    "definition": "Format de grafică vectorială descris în XML; se scalează fără pierderi de calitate.",
    "definitionRu": "Описывает масштабируемую векторную графику элементами документа."
  },
  {
    "term": "Modelul cutiei (box model)",
    "course": "html5",
    "module": "03-formatare-css",
    "definition": "Fiecare element este o cutie formată din conținut, padding, bordură și margine. box-sizing: border-box include padding-ul și bordura în lățime."
  },
  {
    "term": "Specificitate",
    "course": "html5",
    "module": "03-formatare-css",
    "definition": "Regula care decide ce declarație CSS câștigă: stil inline > ID > clasă / atribut / pseudo-clasă > element."
  },
  {
    "term": "Flexbox",
    "course": "html5",
    "module": "03-formatare-css",
    "definition": "Model de așezare pe o singură axă; justify-content aliniază pe axa principală, align-items pe cea transversală."
  },
  {
    "term": "Media query",
    "course": "html5",
    "module": "03-formatare-css",
    "definition": "Regulă CSS aplicată doar în anumite condiții (lățimea ecranului, orientarea), baza designului responsiv.",
    "example": "@media (max-width: 600px) { ... }",
    "definitionRu": "Условно применяет CSS, например при определённой ширине экрана."
  },
  {
    "term": "DOM",
    "course": "html5",
    "module": "04-javascript",
    "definition": "Document Object Model: reprezentarea paginii ca arbore de obiecte, pe care JavaScript îl poate citi și modifica."
  },
  {
    "term": "Eveniment (event)",
    "course": "html5",
    "module": "04-javascript",
    "definition": "Acțiune la care poate reacționa codul (click, input, submit), tratată cu addEventListener."
  },
  {
    "term": "localStorage / sessionStorage",
    "course": "html5",
    "module": "01-ciclu-viata",
    "definition": "API-uri pentru stocarea perechilor cheie-valoare în browser; localStorage persistă, sessionStorage durează doar cât fila."
  },
  {
    "term": "Service worker",
    "course": "html5",
    "module": "01-ciclu-viata",
    "definition": "Script care rulează în fundal, separat de pagină, și poate intercepta cererile de rețea pentru cache și funcționare offline.",
    "definitionRu": "Может перехватывать сетевые запросы и реализовывать офлайн-кеш."
  },
  {
    "term": "Web app manifest",
    "course": "html5",
    "module": "01-ciclu-viata",
    "definition": "Fișier JSON cu numele, iconițele și modul de afișare ale unei aplicații web progresive (PWA)."
  },
  {
    "term": "Driver",
    "course": "configurare-dispozitive",
    "module": "01-configurare",
    "definition": "Software care permite sistemului de operare să comunice cu un dispozitiv hardware. Se gestionează din Device Manager.",
    "definitionRu": "Обеспечивает взаимодействие ОС с конкретным оборудованием."
  },
  {
    "term": "Device Manager",
    "course": "configurare-dispozitive",
    "module": "01-configurare",
    "definition": "Consola Windows care listează hardware-ul instalat și permite actualizarea, dezactivarea sau revenirea driverelor.",
    "definitionRu": "Показывает оборудование и состояние драйверов."
  },
  {
    "term": "Periferic",
    "course": "configurare-dispozitive",
    "module": "01-configurare",
    "definition": "Dispozitiv extern conectat la calculator (imprimantă, monitor, căști), prin porturi precum USB, USB-C, HDMI, audio, Ethernet."
  },
  {
    "term": "Windows Update",
    "course": "configurare-dispozitive",
    "module": "01-configurare",
    "definition": "Serviciul care descarcă și instalează actualizări de securitate, de calitate și de funcții pentru Windows.",
    "definitionRu": "Доставляет исправления и обновления безопасности поддерживаемой ОС."
  },
  {
    "term": "NTFS / FAT32 / exFAT",
    "course": "configurare-dispozitive",
    "module": "02-acces-date",
    "definition": "Sisteme de fișiere. NTFS: permisiuni, criptare, jurnalizare. FAT32: compatibil, fișiere max. 4 GB. exFAT: pentru stick-uri mari, fără permisiuni."
  },
  {
    "term": "Permisiuni NTFS",
    "course": "configurare-dispozitive",
    "module": "02-acces-date",
    "definition": "Drepturi pe fișiere și foldere (Read, Write, Modify, Full Control). Combinate cu permisiunile de partajare, se aplică cea mai restrictivă."
  },
  {
    "term": "Backup complet / incremental / diferențial",
    "course": "configurare-dispozitive",
    "module": "02-acces-date",
    "definition": "Complet: toate datele. Incremental: modificările de la ultimul backup. Diferențial: modificările de la ultimul backup complet."
  },
  {
    "term": "BitLocker",
    "course": "configurare-dispozitive",
    "module": "03-securitate",
    "definition": "Funcție Windows care criptează volume întregi; cheia de recuperare trebuie păstrată în siguranță.",
    "definitionRu": "Шифрует диск Windows для защиты сохранённых данных."
  },
  {
    "term": "UAC (User Account Control)",
    "course": "configurare-dispozitive",
    "module": "03-securitate",
    "definition": "Mecanism care cere confirmarea înainte ca o aplicație să primească drepturi de administrator."
  },
  {
    "term": "Autentificare multi-factor (MFA)",
    "course": "configurare-dispozitive",
    "module": "03-securitate",
    "definition": "Verificarea identității cu cel puțin doi factori: ceva ce știi (parolă), ceva ce ai (telefon), ceva ce ești (amprentă).",
    "definitionRu": "Требует независимых типов факторов аутентификации."
  },
  {
    "term": "Safe Mode",
    "course": "configurare-dispozitive",
    "module": "04-depanare",
    "definition": "Mod de pornire Windows cu un set minim de drivere și servicii, folosit pentru a diagnostica probleme.",
    "definitionRu": "Запускает Windows с минимальным набором драйверов и служб."
  },
  {
    "term": "System Restore",
    "course": "configurare-dispozitive",
    "module": "04-depanare",
    "definition": "Readuce fișierele de sistem și setările la un punct de restaurare anterior, fără a afecta documentele personale."
  },
  {
    "term": "Event Viewer",
    "course": "configurare-dispozitive",
    "module": "04-depanare",
    "definition": "Consola care afișează jurnalele de evenimente (Aplicație, Sistem, Securitate) pentru diagnosticarea erorilor.",
    "definitionRu": "Предоставляет доступ к журналам событий Windows."
  },
  {
    "term": "int()",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Convertește un text compatibil sau un număr într-un număr întreg.",
    "definitionRu": "Преобразует подходящую строку или число в целое число."
  },
  {
    "term": "//",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Împarte numerele și rotunjește câtul în jos, la o valoare întreagă.",
    "definitionRu": "Делит числа и округляет частное вниз до целого значения."
  },
  {
    "term": "%",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Returnează restul împărțirii.",
    "definitionRu": "Возвращает остаток от деления."
  },
  {
    "term": "input()",
    "course": "python",
    "module": "03-intrare-iesire",
    "definition": "Citește o linie din intrarea standard și o returnează ca șir de caractere.",
    "definitionRu": "Считывает строку из стандартного ввода и возвращает str."
  },
  {
    "term": "list.append(x)",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Adaugă un element la sfârșitul unei secvențe mutabile.",
    "definitionRu": "Добавляет один элемент в конец изменяемой последовательности."
  },
  {
    "term": "items[-1]",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Returnează ultimul element al unei secvențe nevide.",
    "definitionRu": "Получает последний элемент непустой последовательности."
  },
  {
    "term": "items[1:3]",
    "course": "python",
    "module": "01-tipuri-date-operatori",
    "definition": "Returnează elementele cu indicii 1 și 2, fără indicele 3.",
    "definitionRu": "Получает элементы с индексами 1 и 2, исключая индекс 3."
  },
  {
    "term": "return",
    "course": "python",
    "module": "04-documentare-structura",
    "definition": "Trimite un rezultat apelantului și încheie funcția curentă.",
    "definitionRu": "Возвращает результат вызывающему коду и завершает текущую функцию."
  },
  {
    "term": "elif",
    "course": "python",
    "module": "02-control-flux",
    "definition": "Verifică o altă condiție atunci când ramurile anterioare nu s-au potrivit.",
    "definitionRu": "Проверяет следующее условие, если предыдущие ветви не подошли."
  },
  {
    "term": "def",
    "course": "python",
    "module": "04-documentare-structura",
    "definition": "Începe definiția unei funcții cu nume.",
    "definitionRu": "Начинает определение именованной функции."
  },
  {
    "term": "range(1, 5)",
    "course": "python",
    "module": "02-control-flux",
    "definition": "La parcurgere produce secvența de numere întregi 1, 2, 3, 4.",
    "definitionRu": "При переборе создаёт последовательность целых чисел 1, 2, 3, 4."
  },
  {
    "term": "break",
    "course": "python",
    "module": "02-control-flux",
    "definition": "Iese imediat din cea mai apropiată buclă care îl conține.",
    "definitionRu": "Немедленно завершает ближайший охватывающий цикл."
  },
  {
    "term": "continue",
    "course": "python",
    "module": "02-control-flux",
    "definition": "Sare peste instrucțiunile rămase din iterația curentă a buclei.",
    "definitionRu": "Пропускает оставшиеся команды текущей итерации цикла."
  },
  {
    "term": "while",
    "course": "python",
    "module": "02-control-flux",
    "definition": "Repetă un bloc cât timp o condiție rămâne adevărată.",
    "definitionRu": "Повторяет блок, пока условие остаётся истинным."
  },
  {
    "term": "with open(path)",
    "course": "python",
    "module": "03-intrare-iesire",
    "definition": "Folosește un manager de context pentru a închide fișierul în siguranță.",
    "definitionRu": "Использует контекстный менеджер для надёжного закрытия файла."
  },
  {
    "term": "open(path, 'a')",
    "course": "python",
    "module": "03-intrare-iesire",
    "definition": "Deschide un fișier text pentru scriere la sfârșit, fără a-i șterge conținutul.",
    "definitionRu": "Открывает текстовый файл для дописывания без удаления содержимого."
  },
  {
    "term": "ValueError",
    "course": "python",
    "module": "05-depanare-erori",
    "definition": "Poate fi ridicată de int() când primește un text precum „hello”.",
    "definitionRu": "Может возникнуть в int() при передаче строки вроде \"hello\"."
  },
  {
    "term": "finally",
    "course": "python",
    "module": "05-depanare-erori",
    "definition": "Își execută blocul la ieșirea din try, indiferent dacă a apărut o excepție.",
    "definitionRu": "Выполняет свой блок при выходе из try независимо от исключения."
  },
  {
    "term": "import math",
    "course": "python",
    "module": "06-module-instrumente",
    "definition": "Face disponibil modulul standard de matematică sub numele său.",
    "definitionRu": "Подключает стандартный математический модуль под его именем."
  },
  {
    "term": "CREATE TABLE",
    "course": "baze-de-date",
    "module": "02-obiecte",
    "definition": "Definește un tabel nou, cu coloane și constrângeri.",
    "definitionRu": "Определяет новую таблицу со столбцами и ограничениями."
  },
  {
    "term": "ALTER TABLE",
    "course": "baze-de-date",
    "module": "02-obiecte",
    "definition": "Modifică structura unui tabel existent.",
    "definitionRu": "Изменяет структуру существующей таблицы."
  },
  {
    "term": "CHECK",
    "course": "baze-de-date",
    "module": "02-obiecte",
    "definition": "Respinge un rând atunci când condiția constrângerii se evaluează la fals.",
    "definitionRu": "Отклоняет строку, если условие ограничения имеет значение false."
  },
  {
    "term": "NOT NULL",
    "course": "baze-de-date",
    "module": "02-obiecte",
    "definition": "Cere ca o coloană să conțină o valoare diferită de NULL.",
    "definitionRu": "Требует ненулевого значения в столбце."
  },
  {
    "term": "WHERE",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Filtrează rândurile individuale înainte de grupare.",
    "definitionRu": "Фильтрует отдельные строки до группировки."
  },
  {
    "term": "ORDER BY",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Sortează rezultatul unei interogări după expresiile specificate.",
    "definitionRu": "Сортирует результат запроса по указанным выражениям."
  },
  {
    "term": "IS NULL",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Verifică dacă o valoare lipsește, în loc să o compare cu operatorul egal.",
    "definitionRu": "Проверяет отсутствие значения вместо сравнения через знак равенства."
  },
  {
    "term": "DISTINCT",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Elimină rândurile duplicate din rezultatul unui SELECT.",
    "definitionRu": "Убирает повторяющиеся строки результата SELECT."
  },
  {
    "term": "GROUP BY",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Împarte rândurile de intrare în grupuri pentru agregare.",
    "definitionRu": "Разбивает строки на группы для агрегации."
  },
  {
    "term": "HAVING",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Filtrează grupurile după agregare.",
    "definitionRu": "Фильтрует группы после агрегации."
  },
  {
    "term": "COUNT(column)",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Numără valorile diferite de NULL din coloana specificată.",
    "definitionRu": "Считает значения указанного столбца, исключая NULL."
  },
  {
    "term": "UNION ALL",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Combină rezultate compatibile ale interogărilor, păstrând duplicatele.",
    "definitionRu": "Объединяет совместимые результаты запросов с сохранением повторов."
  },
  {
    "term": "LEFT JOIN",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Păstrează fiecare rând din stânga, chiar dacă niciun rând din dreapta nu se potrivește.",
    "definitionRu": "Сохраняет все строки слева даже без совпадения справа."
  },
  {
    "term": "INNER JOIN",
    "course": "baze-de-date",
    "module": "03-interogare",
    "definition": "Returnează combinațiile de rânduri care îndeplinesc condiția de îmbinare.",
    "definitionRu": "Возвращает сочетания строк, удовлетворяющие условию соединения."
  },
  {
    "term": "UPDATE",
    "course": "baze-de-date",
    "module": "04-manipulare",
    "definition": "Modifică rândurile existente; fără WHERE poate afecta toate rândurile.",
    "definitionRu": "Изменяет существующие строки; без WHERE может затронуть все строки."
  },
  {
    "term": "ROLLBACK",
    "course": "baze-de-date",
    "module": "04-manipulare",
    "definition": "Anulează modificările tranzacției curente care nu au fost confirmate.",
    "definitionRu": "Отменяет изменения текущей незафиксированной транзакции."
  },
  {
    "term": "COMMIT",
    "course": "baze-de-date",
    "module": "04-manipulare",
    "definition": "Face permanente modificările tranzacției curente.",
    "definitionRu": "Фиксирует изменения текущей транзакции."
  },
  {
    "term": "LAN",
    "course": "retelistica",
    "module": "01-infrastructura",
    "definition": "Conectează dispozitive dintr-o zonă geografică locală, limitată.",
    "definitionRu": "Соединяет устройства в ограниченной локальной области."
  },
  {
    "term": "WAN",
    "course": "retelistica",
    "module": "01-infrastructura",
    "definition": "Conectează rețele aflate la mari distanțe geografice.",
    "definitionRu": "Соединяет сети на больших географических расстояниях."
  },
  {
    "term": "Latență (latency)",
    "termRu": "Задержка (latency)",
    "course": "retelistica",
    "module": "01-infrastructura",
    "definition": "Măsoară întârzierea de timp la livrarea datelor.",
    "definitionRu": "Измеряет временную задержку передачи данных."
  },
  {
    "term": "TCP",
    "course": "retelistica",
    "module": "03-protocoale-servicii",
    "definition": "Oferă transport ordonat și fiabil, cu retransmisie.",
    "definitionRu": "Обеспечивает упорядоченную надёжную доставку с повторной передачей."
  },
  {
    "term": "UDP",
    "course": "retelistica",
    "module": "03-protocoale-servicii",
    "definition": "Oferă datagrame fără garanții integrate de livrare sau ordonare.",
    "definitionRu": "Передаёт датаграммы без встроенных гарантий доставки и порядка."
  },
  {
    "term": "Nivelul 3 OSI",
    "termRu": "Уровень 3 OSI",
    "course": "retelistica",
    "module": "03-protocoale-servicii",
    "definition": "Gestionează adresarea logică și dirijarea pachetelor de rețea.",
    "definitionRu": "Отвечает за логическую адресацию и маршрутизацию пакетов."
  },
  {
    "term": "IPv6",
    "course": "retelistica",
    "module": "01-infrastructura",
    "definition": "Folosește adrese pe 128 de biți.",
    "definitionRu": "Использует 128-битные адреса."
  },
  {
    "term": "Subrețea IPv4 /24",
    "termRu": "Подсеть IPv4 /24",
    "course": "retelistica",
    "module": "01-infrastructura",
    "definition": "Oferă în mod obișnuit 254 de adrese utilizabile pentru gazde într-o subrețea convențională.",
    "definitionRu": "Обычно предоставляет 254 доступных адреса узлов в традиционной подсети."
  },
  {
    "term": "Fibră optică (optical fiber)",
    "termRu": "Оптоволокно (optical fiber)",
    "course": "retelistica",
    "module": "02-hardware",
    "definition": "Transportă semnale luminoase și rezistă la interferențele electromagnetice.",
    "definitionRu": "Передаёт световые сигналы и устойчива к электромагнитным помехам."
  },
  {
    "term": "Portul TCP 443",
    "termRu": "TCP-порт 443",
    "course": "retelistica",
    "module": "03-protocoale-servicii",
    "definition": "Este portul de destinație convențional pentru traficul HTTPS.",
    "definitionRu": "Является стандартным портом назначения HTTPS."
  },
  {
    "term": "Portul TCP 22",
    "termRu": "TCP-порт 22",
    "course": "retelistica",
    "module": "03-protocoale-servicii",
    "definition": "Este portul de destinație convențional pentru traficul SSH.",
    "definitionRu": "Является стандартным портом назначения SSH."
  },
  {
    "term": "ping",
    "course": "retelistica",
    "module": "05-depanare",
    "definition": "Verifică accesibilitatea folosind cereri ICMP echo.",
    "definitionRu": "Проверяет доступность с помощью ICMP echo request."
  },
  {
    "term": "traceroute",
    "course": "retelistica",
    "module": "05-depanare",
    "definition": "Ajută la identificarea salturilor intermediare de pe o cale din rețea.",
    "definitionRu": "Помогает определить промежуточные узлы сетевого маршрута."
  },
  {
    "term": "nslookup",
    "course": "retelistica",
    "module": "05-depanare",
    "definition": "Interoghează DNS pentru a ajuta la diagnosticarea problemelor de rezolvare a numelor.",
    "definitionRu": "Запрашивает DNS для диагностики разрешения имён."
  },
  {
    "term": "<main>",
    "course": "html5",
    "module": "02-interfata-html5",
    "definition": "Identifică conținutul principal al unui document HTML.",
    "definitionRu": "Обозначает основное содержимое HTML-документа."
  },
  {
    "term": "<nav>",
    "course": "html5",
    "module": "02-interfata-html5",
    "definition": "Marchează o secțiune cu linkurile principale de navigare.",
    "definitionRu": "Обозначает раздел основных навигационных ссылок."
  },
  {
    "term": "alt",
    "course": "html5",
    "module": "02-interfata-html5",
    "definition": "Oferă o alternativă text pentru o imagine.",
    "definitionRu": "Предоставляет текстовую альтернативу изображению."
  },
  {
    "term": "<label for=\"email\">",
    "course": "html5",
    "module": "02-interfata-html5",
    "definition": "Asociază o etichetă vizibilă cu controlul al cărui id este email.",
    "definitionRu": "Связывает видимую подпись с полем, у которого id равен email."
  },
  {
    "term": "required",
    "course": "html5",
    "module": "02-interfata-html5",
    "definition": "Activează verificarea nativă a formularului: o valoare trebuie furnizată.",
    "definitionRu": "Включает встроенную проверку обязательного заполнения поля."
  },
  {
    "term": "padding",
    "course": "html5",
    "module": "03-formatare-css",
    "definition": "Adaugă spațiu între conținut și bordura sa.",
    "definitionRu": "Задаёт расстояние между содержимым и рамкой."
  },
  {
    "term": "margin",
    "course": "html5",
    "module": "03-formatare-css",
    "definition": "Adaugă spațiu în afara bordurii unei casete CSS.",
    "definitionRu": "Задаёт расстояние за пределами рамки CSS-блока."
  },
  {
    "term": "box-sizing: border-box",
    "course": "html5",
    "module": "03-formatare-css",
    "definition": "Include bordura și padding-ul în lățimea declarată.",
    "definitionRu": "Включает рамку и внутренние отступы в объявленную ширину."
  },
  {
    "term": "#menu",
    "course": "html5",
    "module": "03-formatare-css",
    "definition": "Selectează în CSS elementul cu id-ul menu.",
    "definitionRu": "Выбирает в CSS элемент с id menu."
  },
  {
    "term": "display: grid",
    "course": "html5",
    "module": "03-formatare-css",
    "definition": "Creează un sistem de machetare cu rânduri și coloane explicite.",
    "definitionRu": "Создаёт систему раскладки с явными строками и столбцами."
  },
  {
    "term": "prefers-reduced-motion",
    "course": "html5",
    "module": "03-formatare-css",
    "definition": "Detectează preferința utilizatorului pentru mai puține animații.",
    "definitionRu": "Определяет предпочтение пользователя уменьшить анимацию."
  },
  {
    "term": "document.querySelector()",
    "course": "html5",
    "module": "04-javascript",
    "definition": "Returnează primul element care se potrivește sau null.",
    "definitionRu": "Возвращает первый подходящий элемент или null."
  },
  {
    "term": "addEventListener()",
    "course": "html5",
    "module": "04-javascript",
    "definition": "Înregistrează un handler pentru un eveniment al unei ținte de evenimente.",
    "definitionRu": "Регистрирует обработчик события для EventTarget."
  },
  {
    "term": "event.preventDefault()",
    "course": "html5",
    "module": "04-javascript",
    "definition": "Anulează acțiunea implicită a browserului pentru un eveniment anulabil.",
    "definitionRu": "Отменяет стандартное действие браузера для отменяемого события."
  },
  {
    "term": "textContent",
    "course": "html5",
    "module": "04-javascript",
    "definition": "Setează text simplu, fără a-l interpreta ca marcaj HTML.",
    "definitionRu": "Задаёт обычный текст без интерпретации HTML-разметки."
  },
  {
    "term": "sessionStorage",
    "course": "html5",
    "module": "01-ciclu-viata",
    "definition": "Stochează valori text limitate la o origine și la sesiunea unei file.",
    "definitionRu": "Хранит строки в рамках origin и сессии вкладки."
  },
  {
    "term": "RAM",
    "course": "configurare-dispozitive",
    "module": "01-configurare",
    "definition": "Păstrează datele de lucru volatile folosite de programele în execuție.",
    "definitionRu": "Хранит энергозависимые рабочие данные запущенных программ."
  },
  {
    "term": "SSD",
    "course": "configurare-dispozitive",
    "module": "01-configurare",
    "definition": "Stochează datele permanent, fără piese mecanice în mișcare.",
    "definitionRu": "Сохраняет данные без механических движущихся частей."
  },
  {
    "term": "HDMI",
    "course": "configurare-dispozitive",
    "module": "01-configurare",
    "definition": "Transmite video și audio digital către ecrane compatibile.",
    "definitionRu": "Передаёт цифровое видео и звук на совместимые дисплеи."
  },
  {
    "term": "UEFI",
    "course": "configurare-dispozitive",
    "module": "01-configurare",
    "definition": "Oferă serviciile de firmware folosite pentru inițializarea hardware-ului și pornirea sistemului de operare.",
    "definitionRu": "Предоставляет службы прошивки для инициализации оборудования и запуска ОС."
  },
  {
    "term": "NTFS",
    "course": "configurare-dispozitive",
    "module": "02-acces-date",
    "definition": "Acceptă liste de control al accesului (ACL) pentru sistemul de fișiere Windows.",
    "definitionRu": "Поддерживает списки управления доступом файловой системы Windows."
  },
  {
    "term": "FAT32",
    "course": "configurare-dispozitive",
    "module": "02-acces-date",
    "definition": "Limitează dimensiunea unui singur fișier la mai puțin de 4 GiB.",
    "definitionRu": "Ограничивает размер одного файла величиной меньше 4 ГиБ."
  },
  {
    "term": "Privilegiu minim (least privilege)",
    "termRu": "Минимальные привилегии (least privilege)",
    "course": "configurare-dispozitive",
    "module": "03-securitate",
    "definition": "Acordă doar accesul necesar pentru o sarcină anume.",
    "definitionRu": "Предоставляет только права, необходимые для конкретной задачи."
  },
  {
    "term": "Cont de utilizator standard",
    "termRu": "Стандартная учётная запись",
    "course": "configurare-dispozitive",
    "module": "03-securitate",
    "definition": "Permite munca obișnuită fără privilegii administrative implicite.",
    "definitionRu": "Позволяет выполнять повседневную работу без стандартных прав администратора."
  },
  {
    "term": "Blocare ecran (screen lock)",
    "termRu": "Блокировка экрана (screen lock)",
    "course": "configurare-dispozitive",
    "module": "03-securitate",
    "definition": "Protejează o sesiune interactivă nesupravegheată de accesul ocazional.",
    "definitionRu": "Защищает оставленный интерактивный сеанс от постороннего доступа."
  },
  {
    "term": "Copie de rezervă completă (full backup)",
    "termRu": "Полная резервная копия (full backup)",
    "course": "configurare-dispozitive",
    "module": "02-acces-date",
    "definition": "Copiază într-o singură operațiune toate datele selectate.",
    "definitionRu": "Копирует все выбранные данные за одну операцию резервирования."
  },
  {
    "term": "Copie de rezervă incrementală (incremental backup)",
    "termRu": "Инкрементная резервная копия (incremental backup)",
    "course": "configurare-dispozitive",
    "module": "02-acces-date",
    "definition": "Copiază datele modificate de la copia de rezervă anterioară.",
    "definitionRu": "Копирует данные, изменившиеся с предыдущего резервного копирования."
  },
  {
    "term": "Test de restaurare (restore test)",
    "termRu": "Проверка восстановления (restore test)",
    "course": "configurare-dispozitive",
    "module": "02-acces-date",
    "definition": "Verifică dacă datele salvate pot fi recuperate cu adevărat.",
    "definitionRu": "Проверяет возможность фактического восстановления резервной копии."
  },
  {
    "term": "Task Manager",
    "course": "configurare-dispozitive",
    "module": "04-depanare",
    "definition": "Afișează procesele în execuție și utilizarea resurselor.",
    "definitionRu": "Показывает процессы и использование ресурсов."
  }
]
