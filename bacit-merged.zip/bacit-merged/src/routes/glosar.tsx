import { useMemo, useState } from 'react'
import { createFileRoute, Link } from '@tanstack/react-router'
import { Search } from 'lucide-react'

import { CodeBlock } from '@/components/bacit/question-view'
import { PageHeader } from '@/components/bacit/page-header'
import { Input } from '@/components/ui/input'
import { courseColor, courses } from '@/data/courses'
import { glossary, type GlossaryTerm } from '@/data/glossary'
import { useLang, useT, type Lang } from '@/lib/i18n'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/glosar')({
  head: () => ({ meta: [{ title: 'Glosar Certiport · BacIt' }] }),
  component: GlossaryPage,
})

/** Lowercase and strip diacritics so "retea" finds "rețea". */
function normalize(text: string) {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
}

const termName = (t: GlossaryTerm, lang: Lang) => (lang === 'ru' ? (t.termRu ?? t.term) : t.term)
const termText = (t: GlossaryTerm, lang: Lang) =>
  lang === 'ru' ? (t.definitionRu ?? t.definition) : t.definition

function GlossaryPage() {
  const t = useT()
  const lang = useLang()
  const [query, setQuery] = useState('')
  const [courseId, setCourseId] = useState<string | null>(null)

  const results = useMemo(() => {
    const q = normalize(query.trim())
    return glossary
      .filter((g) => !courseId || g.course === courseId)
      .filter(
        (g) =>
          !q ||
          normalize(termName(g, lang)).includes(q) ||
          normalize(termText(g, lang)).includes(q),
      )
      .sort((a, b) => termName(a, lang).localeCompare(termName(b, lang), lang))
  }, [query, courseId, lang])

  return (
    <div className="mx-auto max-w-content px-4 sm:px-6">
      <PageHeader
        eyebrow={t('Glosar Certiport', 'Глоссарий Certiport')}
        title={t('Termenii din obiectivele examenelor', 'Термины из целей экзаменов')}
        description={t(
          `${glossary.length} de definiții scurte, grupate pe cursuri și module. Caută un termen sau filtrează după curs.`,
          `${glossary.length} коротких определений по курсам и модулям. Найдите термин или отфильтруйте по курсу.`,
        )}
      />
      <div className="mb-6 space-y-4">
        <div className="relative max-w-md">
          <Search
            className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <Input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('Caută un termen…', 'Найти термин…')}
            aria-label={t('Caută în glosar', 'Поиск по глоссарию')}
            className="h-11 bg-card pl-9"
          />
        </div>
        <div className="flex flex-wrap gap-2" role="group" aria-label={t('Filtrează după curs', 'Фильтр по курсу')}>
          <FilterChip active={!courseId} onClick={() => setCourseId(null)}>
            {t('Toate', 'Все')} ({glossary.length})
          </FilterChip>
          {courses.map((c) => (
            <FilterChip
              key={c.id}
              active={courseId === c.id}
              onClick={() => setCourseId(c.id)}
              color={courseColor(c)}
            >
              {c.title} ({glossary.filter((g) => g.course === c.id).length})
            </FilterChip>
          ))}
        </div>
      </div>

      <p className="mb-4 text-sm text-muted-foreground" aria-live="polite">
        {results.length}{' '}
        {lang === 'ru' ? 'терм.' : results.length === 1 ? 'termen' : 'termeni'}
      </p>

      {results.length === 0 ? (
        <p className="rounded-2xl border border-dashed p-10 text-center text-muted-foreground">
          {t(
            'Niciun termen nu se potrivește căutării. Încearcă alt cuvânt.',
            'Ничего не найдено. Попробуйте другое слово.',
          )}
        </p>
      ) : (
        <dl className="grid gap-4 md:grid-cols-2">
          {results.map((g) => {
            const course = courses.find((c) => c.id === g.course)
            const module = course?.modules.find((m) => m.id === g.module)
            return (
              <div
                key={`${g.course}-${g.term}`}
                className="space-y-2 rounded-2xl border bg-card p-5 shadow-xs"
                style={course ? { borderLeft: `4px solid ${courseColor(course)}` } : undefined}
              >
                <dt className="text-lg font-bold">{termName(g, lang)}</dt>
                <dd className="space-y-3">
                  <p className="text-sm text-foreground/85">{termText(g, lang)}</p>
                  {g.example && <CodeBlock code={g.example} />}
                  {course && (
                    <p className="text-xs text-muted-foreground">
                      <Link
                        to="/cursuri/$courseId"
                        params={{ courseId: course.id }}
                        className="font-semibold hover:text-foreground"
                      >
                        {course.title}
                      </Link>
                      {module && ` · ${module.title}`}
                    </p>
                  )}
                </dd>
              </div>
            )
          })}
        </dl>
      )}
    </div>
  )
}

function FilterChip({
  active,
  onClick,
  color,
  children,
}: {
  active: boolean
  onClick: () => void
  color?: string
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        'inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1.5 text-sm font-medium transition-colors hover:border-primary/40 motion-reduce:transition-none',
        active && 'border-primary bg-accent text-accent-foreground',
      )}
    >
      {color && <span className="size-2 rounded-full" style={{ background: color }} />}
      {children}
    </button>
  )
}
