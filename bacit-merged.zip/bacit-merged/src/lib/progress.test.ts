import { describe, expect, it } from 'vitest'

import { mergeProgress, normalizeProgress } from './progress'

const empty = normalizeProgress({})

describe('mergeProgress', () => {
  it('keeps everything earned on both sides', () => {
    const local = normalizeProgress({
      watched: { a: true },
      xp: 50,
      answers: { q1: { correct: true, attempts: 1, at: 200 } },
      daily: { '2026-10-26': { python: 3 } },
    })
    const remote = normalizeProgress({
      watched: { b: true },
      xp: 80,
      answers: { q1: { correct: false, attempts: 2, at: 100 }, q2: { correct: true, attempts: 1, at: 50 } },
      daily: { '2026-10-26': { python: 5, html5: 1 } },
    })
    const merged = mergeProgress(local, remote)
    expect(Object.keys(merged.watched).sort()).toEqual(['a', 'b'])
    expect(merged.xp).toBe(80)
    expect(merged.answers.q1).toEqual({ correct: true, attempts: 2, at: 200 })
    expect(merged.answers.q2.correct).toBe(true)
    expect(merged.daily['2026-10-26']).toEqual({ python: 5, html5: 1 })
  })

  it('does not bring back a lesson that was un-marked locally since the last sync', () => {
    const base = normalizeProgress({ watched: { a: true, b: true } })
    const local = normalizeProgress({ watched: { a: true } })
    const remote = normalizeProgress({ watched: { a: true, b: true } })
    expect(Object.keys(mergeProgress(local, remote, base).watched)).toEqual(['a'])
  })

  it('merges exams by id and prefers a customised local profile', () => {
    const exam = (id: string, at: number) => ({
      id, course: 'python', variant: 1, percent: 80, correct: 32, total: 40, at, seconds: 900, domains: [],
    })
    const local = normalizeProgress({ exams: [exam('x', 2)], profile: { ...empty.profile, name: 'Ana' } })
    const remote = normalizeProgress({ exams: [exam('x', 2), exam('y', 1)] })
    const merged = mergeProgress(local, remote)
    expect(merged.exams.map((e) => e.id)).toEqual(['y', 'x'])
    expect(merged.profile.name).toBe('Ana')
  })
})
