import { useEffect, useSyncExternalStore } from 'react'

import { useAuth } from './auth'
import {
  getProgress,
  mergeProgress,
  normalizeProgress,
  replaceProgress,
  subscribeProgress,
  type ProgressState,
} from './progress'

export type SyncStatus = 'off' | 'syncing' | 'saved' | 'error'

let status: SyncStatus = 'off'
let lastSavedAt: number | null = null
const listeners = new Set<() => void>()

type Snapshot = { status: SyncStatus; at: number | null }
let snapshot: Snapshot = { status, at: lastSavedAt }

function setStatus(next: SyncStatus) {
  status = next
  if (next === 'saved') lastSavedAt = Date.now()
  snapshot = { status, at: lastSavedAt }
  listeners.forEach((l) => l())
}

const serverSnapshot: Snapshot = { status: 'off', at: null }

/** Whether this browser's progress is saved to the signed-in account. */
export function useSyncStatus(): Snapshot {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l)
      return () => listeners.delete(l)
    },
    () => snapshot,
    () => serverSnapshot,
  )
}

type ServerState = { progress: Partial<ProgressState> | null; examTimes: number[] }

async function api(method: 'GET' | 'PUT' | 'POST' | 'DELETE', body?: unknown) {
  const res = await fetch('/api/learning', {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  })
  const json = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((json as { error?: string }).error || `HTTP ${res.status}`)
  return json
}

/** Removes the account's saved progress (used by "reset progress"). */
export async function deleteRemoteProgress() {
  await api('DELETE')
}

function startSync(): () => void {
  let stopped = false
  let timer: ReturnType<typeof setTimeout> | undefined
  let running = false
  let again = false
  let base: ProgressState | null = null
  const sentExams = new Set<number>()

  async function flush() {
    if (running) {
      again = true
      return
    }
    running = true
    setStatus('syncing')
    try {
      const remote = (await api('GET')) as ServerState
      remote.examTimes.forEach((t) => sentExams.add(t))
      const merged = mergeProgress(getProgress(), remote.progress, base)
      if (stopped) return
      if (JSON.stringify(merged) !== JSON.stringify(getProgress())) replaceProgress(merged)
      await api('PUT', { progress: merged })
      for (const exam of merged.exams) {
        if (sentExams.has(exam.at)) continue
        await api('POST', { action: 'exam', exam })
        sentExams.add(exam.at)
      }
      base = normalizeProgress(merged)
      if (!stopped) setStatus('saved')
    } catch {
      if (!stopped) setStatus('error')
    } finally {
      running = false
      if (again && !stopped) {
        again = false
        schedule(500)
      }
    }
  }

  function schedule(delay = 1500) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(flush, delay)
  }

  const unsubscribe = subscribeProgress(() => {
    // Only schedule when something really changed since the last sync.
    if (!base || JSON.stringify(getProgress()) !== JSON.stringify(base)) schedule()
  })
  const online = () => schedule(300)
  window.addEventListener('online', online)
  void flush()

  return () => {
    stopped = true
    if (timer) clearTimeout(timer)
    unsubscribe()
    window.removeEventListener('online', online)
    setStatus('off')
  }
}

/** Mount once (in the header): keeps progress in sync while someone is signed in. */
export function useAccountSync() {
  const { user } = useAuth()
  const id = user?.id
  useEffect(() => {
    if (!id) return
    return startSync()
  }, [id])
}
