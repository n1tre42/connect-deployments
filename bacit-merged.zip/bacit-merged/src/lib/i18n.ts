import { useSyncExternalStore } from 'react'

/** Interface language. Romanian is the default; Russian is chosen by the learner. */
export type Lang = 'ro' | 'ru'

const STORAGE_KEY = 'bacit-lang'

let lang: Lang = 'ro'
let loaded = false
const listeners = new Set<() => void>()

function load() {
  if (loaded || typeof window === 'undefined') return
  loaded = true
  try {
    const saved = localStorage.getItem(STORAGE_KEY)
    if (saved === 'ro' || saved === 'ru') lang = saved
  } catch {
    // Storage disabled: the language resets on the next visit.
  }
}

function subscribe(listener: () => void) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

function getSnapshot(): Lang {
  load()
  return lang
}

export function setLang(next: Lang) {
  load()
  lang = next
  try {
    localStorage.setItem(STORAGE_KEY, next)
  } catch {
    // ignore
  }
  listeners.forEach((l) => l())
}

/** Current interface language as React state (Romanian during the server render). */
export function useLang(): Lang {
  return useSyncExternalStore(subscribe, getSnapshot, () => 'ro' as Lang)
}

/** Returns `t(ro, ru)`, which picks the text for the current language. */
export function useT() {
  const current = useLang()
  return (ro: string, ru: string) => (current === 'ru' ? ru : ro)
}

/** Picks a value from a `{ ro, ru }` pair. */
export function pick<T>(value: { ro: T; ru: T }, current: Lang): T {
  return current === 'ru' ? value.ru : value.ro
}
