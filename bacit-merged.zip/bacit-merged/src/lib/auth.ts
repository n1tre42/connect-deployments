import { useSyncExternalStore } from 'react'
import { getUser, handleAuthCallback, onAuthChange } from '@netlify/identity'

/** The few account fields this app reads. */
export type AuthUser = { id: string; email?: string; name?: string }

/**
 * Account state from Netlify Identity. The account is optional: without one
 * the app keeps working and saves progress in this browser only.
 */
export type AuthState = {
  user: AuthUser | null
  /** False until the first check of the stored session has finished. */
  ready: boolean
  /** Set when the learner arrives from an e-mail link. */
  callback: 'recovery' | 'confirmed' | 'invalid' | null
}

let state: AuthState = { user: null, ready: false, callback: null }
let started = false
const listeners = new Set<() => void>()

function set(next: Partial<AuthState>) {
  state = { ...state, ...next }
  listeners.forEach((l) => l())
}

function start() {
  if (started || typeof window === 'undefined') return
  started = true
  onAuthChange((_event, user) => set({ user }))
  handleAuthCallback()
    .then((result) => {
      if (result?.type === 'recovery') set({ callback: 'recovery' })
      else if (result?.user) set({ user: result.user, callback: 'confirmed' })
    })
    .catch(() => set({ callback: 'invalid' }))
    .finally(() => {
      getUser()
        .then((user) => set({ user: user ?? state.user, ready: true }))
        .catch(() => set({ ready: true }))
    })
}

function subscribe(listener: () => void) {
  start()
  listeners.add(listener)
  return () => listeners.delete(listener)
}

const serverState: AuthState = { user: null, ready: false, callback: null }

export function useAuth(): AuthState {
  return useSyncExternalStore(
    subscribe,
    () => state,
    () => serverState,
  )
}

export function clearAuthCallback() {
  set({ callback: null })
}

export function setAuthUser(user: AuthUser | null) {
  set({ user, ready: true })
}
